package app.boxtube

import android.app.Application
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.IBinder
import android.os.PowerManager

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        Thumbs.init(this)
        Engine.boot(this)
        Downloads.init(this)
    }
}

object Notifs {
    const val CH_DL = "dl"
    const val CH_DONE = "done"
    const val CH_PLAY = "play"
    private var last = 0L

    fun channels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_DL, "Downloads", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_DONE, "Finished downloads", NotificationManager.IMPORTANCE_DEFAULT))
        nm.createNotificationChannel(NotificationChannel(CH_PLAY, "Playback", NotificationManager.IMPORTANCE_LOW))
    }

    private fun open(c: Context): PendingIntent {
        val i = Intent(c, MainActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(c, 1, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun line(t: Task): String {
        var s = t.pct.toInt().toString() + "%"
        if (t.speed > 0.0) s += " · " + U.size(t.speed.toLong()) + "/s"
        if (t.phase.isNotEmpty()) s = t.phase + "…"
        return s
    }

    fun progress(c: Context): Notification {
        channels(c)
        val list = Downloads.runningTasks()
        val b = Notification.Builder(c, CH_DL)
            .setSmallIcon(R.drawable.ic_stat_dl)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open(c))
        if (list.isEmpty()) {
            b.setContentTitle("BoxTube")
            b.setContentText("Preparing…")
            b.setProgress(0, 0, true)
        } else if (list.size == 1) {
            val t = list[0]
            b.setContentTitle(if (t.title.isEmpty()) "Downloading" else t.title)
            b.setContentText(line(t))
            b.setProgress(100, t.pct.toInt(), t.pct <= 0f)
        } else {
            var sum = 0f
            for (t in list) sum += t.pct
            val avg = (sum / list.size).toInt()
            b.setContentTitle("Downloading " + list.size + " files")
            b.setContentText("$avg%")
            b.setProgress(100, avg, false)
        }
        val pa = PendingIntent.getService(
            c, 2, Intent(c, DownloadService::class.java).setAction("pause"), PendingIntent.FLAG_IMMUTABLE
        )
        b.addAction(Notification.Action.Builder(Icon.createWithResource(c, R.drawable.ic_pause), "Pause all", pa).build())
        return b.build()
    }

    /** Keeps the foreground service in step with the queue. */
    fun sync(c: Context) {
        if (Downloads.busy()) {
            if (!DownloadService.up) {
                try {
                    c.startForegroundService(Intent(c, DownloadService::class.java))
                } catch (e: Exception) {
                }
            } else {
                val now = System.currentTimeMillis()
                if (now - last > 900) {
                    last = now
                    try {
                        c.getSystemService(NotificationManager::class.java).notify(DownloadService.NID, progress(c))
                    } catch (e: Exception) {
                    }
                }
            }
        } else if (DownloadService.up) {
            c.stopService(Intent(c, DownloadService::class.java))
        }
    }

    fun done(c: Context, item: Item) {
        if (!Prefs.notif) return
        try {
            channels(c)
            val pi = PendingIntent.getActivity(
                c, item.id.hashCode(), Downloads.playIntent(c, listOf(item), 0),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(c, CH_DONE)
                .setSmallIcon(R.drawable.ic_stat_dl)
                .setContentTitle(item.title)
                .setContentText("Download complete · tap to play")
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build()
            c.getSystemService(NotificationManager::class.java).notify(item.id.hashCode(), n)
        } catch (e: Exception) {
        }
    }
}

/** Foreground service: keeps downloads alive when the app is in the background. */
class DownloadService : Service() {
    companion object {
        const val NID = 4101

        @Volatile
        var up = false
    }

    private var wl: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        up = true
        try {
            startForeground(NID, Notifs.progress(this), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } catch (e: Exception) {
        }
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "boxtube:dl")
            wl?.acquire(6 * 60 * 60 * 1000L)
        } catch (e: Exception) {
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "pause") Downloads.pauseAll()
        try {
            startForeground(NID, Notifs.progress(this), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } catch (e: Exception) {
        }
        if (!Downloads.busy()) stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        up = false
        try {
            val w = wl
            if (w != null && w.isHeld) w.release()
        } catch (e: Exception) {
        }
        super.onDestroy()
    }
}

/** Keeps the process alive while the player runs in the background (audio). */
class KeepService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Notifs.channels(this)
        val title = intent?.getStringExtra("title") ?: "BoxTube"
        val pi = PendingIntent.getActivity(
            this, 3,
            Intent(this, PlayerActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, Notifs.CH_PLAY)
            .setSmallIcon(R.drawable.ic_play)
            .setContentTitle(if (title.isEmpty()) "BoxTube" else title)
            .setContentText("Playing in background")
            .setOngoing(true)
            .setContentIntent(pi)
            .build()
        try {
            startForeground(4102, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } catch (e: Exception) {
        }
        return START_NOT_STICKY
    }
}
