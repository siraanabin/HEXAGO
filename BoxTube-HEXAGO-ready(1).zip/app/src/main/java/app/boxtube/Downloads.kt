package app.boxtube

import android.app.Application
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.ThumbnailUtils
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.provider.MediaStore
import android.util.Size
import com.yausername.youtubedl_android.YoutubeDL
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class Task(
    val id: String,
    val url: String,
    val title: String,
    val who: String,
    val thumb: String,
    val dur: Long,
    val kind: String,
    val res: String,
    val merge: Boolean
) {
    /** q = queued, r = running, p = paused, f = failed, x = cancelled */
    @Volatile var state = "q"
    @Volatile var pct = 0f
    @Volatile var speed = 0.0
    @Volatile var eta = -1L
    @Volatile var err = ""
    @Volatile var wait = ""
    @Volatile var phase = ""
    @Volatile var stage = 0
    var infoFile: String? = null
    var cookie: String? = null

    fun ui(): JSONObject {
        val o = JSONObject()
        o.put("id", id)
        o.put("t", title)
        o.put("w", who)
        o.put("th", thumb)
        o.put("k", kind)
        o.put("s", state)
        o.put("p", pct.toInt())
        o.put("sp", speed)
        o.put("e", eta)
        o.put("er", err)
        o.put("wt", wait)
        o.put("ph", phase)
        o.put("d", dur)
        return o
    }

    fun save(): JSONObject {
        val o = JSONObject()
        o.put("id", id)
        o.put("u", url)
        o.put("t", title)
        o.put("w", who)
        o.put("th", thumb)
        o.put("d", dur)
        o.put("k", kind)
        o.put("r", res)
        o.put("m", merge)
        o.put("s", state)
        o.put("p", pct.toDouble())
        o.put("er", err)
        o.put("i", infoFile ?: "")
        o.put("c", cookie ?: "")
        return o
    }
}

class Item(
    val id: String,
    val title: String,
    val uri: String,
    val mime: String,
    val kind: String,
    val size: Long,
    val dur: Long,
    val thumb: String,
    val who: String,
    val added: Long
) {
    fun ui(): JSONObject {
        val o = JSONObject()
        o.put("id", id)
        o.put("t", title)
        o.put("k", kind)
        o.put("s", size)
        o.put("d", dur)
        o.put("a", added)
        o.put("w", who)
        o.put("tn", if (File(Thumbs.dir, "$id.jpg").exists()) 1 else 0)
        return o
    }

    fun save(): JSONObject {
        val o = JSONObject()
        o.put("id", id)
        o.put("t", title)
        o.put("u", uri)
        o.put("m", mime)
        o.put("k", kind)
        o.put("s", size)
        o.put("d", dur)
        o.put("th", thumb)
        o.put("w", who)
        o.put("a", added)
        return o
    }
}

object Net {
    fun onWifi(c: Context): Boolean {
        return try {
            val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val n = cm.activeNetwork ?: return false
            val cap = cm.getNetworkCapabilities(n) ?: return false
            cap.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || cap.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
        } catch (e: Exception) {
            true
        }
    }
}

object Thumbs {
    lateinit var dir: File

    fun init(c: Context) {
        dir = File(c.filesDir, "thumbs")
        dir.mkdirs()
    }

    /** Saves a small JPEG for the Library: the online thumbnail first, otherwise a frame of the file. */
    fun make(id: String, remote: String, src: File?, audio: Boolean) {
        var bmp: Bitmap? = null
        if (remote.startsWith("http")) {
            try {
                val cn = URL(remote).openConnection() as HttpURLConnection
                cn.connectTimeout = 8000
                cn.readTimeout = 8000
                val b = cn.inputStream.use { it.readBytes() }
                bmp = BitmapFactory.decodeByteArray(b, 0, b.size)
            } catch (e: Exception) {
            }
        }
        if (bmp == null && src != null) {
            try {
                bmp = if (audio) ThumbnailUtils.createAudioThumbnail(src, Size(480, 270), null)
                else ThumbnailUtils.createVideoThumbnail(src, Size(480, 270), null)
            } catch (e: Exception) {
            }
        }
        val b = bmp ?: return
        try {
            val s = if (b.width > 480) Bitmap.createScaledBitmap(b, 480, maxOf(1, b.height * 480 / b.width), true) else b
            File(dir, "$id.jpg").outputStream().use { s.compress(Bitmap.CompressFormat.JPEG, 82, it) }
        } catch (e: Exception) {
        }
    }
}

interface DlListener {
    fun onTasks(a: JSONArray)
    fun onLib(a: JSONArray)
    fun onDone(o: JSONObject)
}

object Downloads {
    private lateinit var app: Application
    lateinit var base: File
    private val lock = Any()
    private val tasks = ArrayList<Task>()
    private val lib = ArrayList<Item>()
    private val pool = Executors.newCachedThreadPool()

    @Volatile
    var listener: DlListener? = null
    private var seq = 0
    private var pushing = false

    private val MIMES = mapOf(
        "mp3" to "audio/mpeg", "m4a" to "audio/mp4", "mp4" to "video/mp4", "webm" to "video/webm",
        "mkv" to "video/x-matroska", "opus" to "audio/ogg", "ogg" to "audio/ogg", "aac" to "audio/aac",
        "flac" to "audio/flac", "wav" to "audio/wav", "mov" to "video/quicktime", "3gp" to "video/3gpp",
        "flv" to "video/x-flv", "avi" to "video/x-msvideo"
    )
    private val RX_YT = Regex("""at\s+([\d.]+)\s*([KMG]i?B)/s""")
    private val RX_AR = Regex("""DL:([\d.]+)([KMG]i?B)""")
    private val RX_AP = Regex("""\((\d+)%\)""")

    fun init(a: Application) {
        app = a
        base = a.getExternalFilesDir(null) ?: a.filesDir
        loadTasks()
        loadLib()
        val dl = File(base, "dl").listFiles()
        if (dl != null) {
            for (d in dl) {
                val keep = synchronized(lock) { tasks.any { it.id == d.name } }
                if (!keep) d.deleteRecursively()
            }
        }
        pool.execute { syncLib() }
        try {
            val cm = a.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    schedule()
                }
            })
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------ persistence
    private fun loadTasks() {
        try {
            val arr = JSONArray(Prefs.str("tasks", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val t = Task(
                    o.getString("id"), o.getString("u"), o.optString("t"), o.optString("w"), o.optString("th"),
                    o.optLong("d"), o.optString("k", "v"), o.optString("r", "720"), o.optBoolean("m")
                )
                t.state = if (o.optString("s") == "f") "f" else "p"
                t.pct = o.optDouble("p", 0.0).toFloat()
                t.err = o.optString("er")
                val inf = o.optString("i")
                if (inf.isNotEmpty()) t.infoFile = inf
                val ck = o.optString("c")
                if (ck.isNotEmpty()) t.cookie = ck
                tasks.add(t)
            }
        } catch (e: Exception) {
        }
    }

    private fun loadLib() {
        try {
            val arr = JSONArray(Prefs.str("lib", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                lib.add(
                    Item(
                        o.getString("id"), o.optString("t"), o.getString("u"), o.optString("m"), o.optString("k", "v"),
                        o.optLong("s"), o.optLong("d"), o.optString("th"), o.optString("w"), o.optLong("a")
                    )
                )
            }
        } catch (e: Exception) {
        }
    }

    private fun persistTasks() {
        val arr = JSONArray()
        synchronized(lock) { for (t in tasks) arr.put(t.save()) }
        Prefs.put("tasks", arr.toString())
    }

    private fun persistLib() {
        val arr = JSONArray()
        synchronized(lock) {
            var n = 0
            for (x in lib) {
                if (n++ >= 500) break
                arr.put(x.save())
            }
        }
        Prefs.put("lib", arr.toString())
    }

    // -------------------------------------------------------------- snapshots
    fun tasksJson(): JSONArray {
        val arr = JSONArray()
        synchronized(lock) { for (t in tasks) arr.put(t.ui()) }
        return arr
    }

    fun libJson(): JSONArray {
        val arr = JSONArray()
        synchronized(lock) { for (x in lib) arr.put(x.ui()) }
        return arr
    }

    fun libSnapshot(): List<Item> = synchronized(lock) { ArrayList(lib) }

    fun findItem(id: String): Item? = synchronized(lock) { lib.firstOrNull { it.id == id } }

    private fun find(id: String): Task? = synchronized(lock) { tasks.firstOrNull { it.id == id } }

    fun busy(): Boolean = synchronized(lock) { tasks.any { it.state == "r" || (it.state == "q" && it.wait.isEmpty()) } }

    fun runningTasks(): List<Task> = synchronized(lock) { tasks.filter { it.state == "r" } }

    private fun push() {
        synchronized(lock) {
            if (pushing) return
            pushing = true
        }
        U.main.postDelayed({
            synchronized(lock) { pushing = false }
            val arr = tasksJson()
            listener?.onTasks(arr)
            Notifs.sync(app)
        }, 350)
    }

    // ---------------------------------------------------------------- control
    fun enqueue(
        i: Info?, url: String, title: String, who: String, thumb: String, dur: Long,
        kind: String, res: String, merge: Boolean, later: Boolean, cookie: File?
    ): Task {
        val id = synchronized(lock) {
            seq++
            "d" + System.currentTimeMillis() + "_" + seq
        }
        val t = Task(id, url, title, who, thumb, dur, kind, res, merge)
        t.infoFile = i?.file?.absolutePath
        t.cookie = cookie?.absolutePath
        t.state = if (later) "p" else "q"
        synchronized(lock) { tasks.add(t) }
        persistTasks()
        push()
        schedule()
        return t
    }

    fun pause(id: String) {
        val t = find(id) ?: return
        val was = t.state
        if (was == "r" || was == "q") {
            t.state = "p"
            t.speed = 0.0
            if (was == "r") Engine.kill(id)
            persistTasks()
            push()
            schedule()
        }
    }

    fun resume(id: String) {
        val t = find(id) ?: return
        if (t.state == "p" || t.state == "f") {
            t.state = "q"
            t.err = ""
            persistTasks()
            schedule()
        }
    }

    fun retry(id: String) {
        val t = find(id) ?: return
        t.infoFile = null
        t.stage = 0
        resume(id)
    }

    fun cancel(id: String) {
        val t = find(id) ?: return
        val was = t.state
        t.state = "x"
        synchronized(lock) { tasks.remove(t) }
        if (was == "r") Engine.kill(id)
        pool.execute {
            Thread.sleep(800)
            File(base, "dl/$id").deleteRecursively()
        }
        persistTasks()
        push()
        schedule()
    }

    fun pauseAll() {
        val ids = synchronized(lock) { tasks.filter { it.state == "r" || it.state == "q" }.map { it.id } }
        for (id in ids) pause(id)
    }

    fun resumeAll() {
        val ids = synchronized(lock) { tasks.filter { it.state == "p" }.map { it.id } }
        for (id in ids) resume(id)
    }

    fun schedule() {
        val start = ArrayList<Task>()
        synchronized(lock) {
            var running = tasks.count { it.state == "r" }
            val max = Prefs.parallel
            val wifiOk = !Prefs.wifiOnly || Net.onWifi(app)
            for (t in tasks) {
                if (running >= max) break
                if (t.state == "q") {
                    if (!wifiOk) {
                        t.wait = "wifi"
                        continue
                    }
                    t.wait = ""
                    t.state = "r"
                    t.speed = 0.0
                    running++
                    start.add(t)
                }
            }
        }
        for (t in start) pool.execute { run(t) }
        push()
    }

    // -------------------------------------------------------------- execution
    private fun mult(u: String): Double = when (u[0]) {
        'K' -> 1024.0
        'M' -> 1048576.0
        'G' -> 1073741824.0
        else -> 1.0
    }

    private fun onLine(t: Task, p: Float, e: Long, l: String?) {
        if (t.state != "r") return
        val line = l ?: ""
        if (line.contains("Destination:")) t.stage++
        if (line.contains("[Merger]") || line.contains("[ExtractAudio]") || line.contains("[VideoRemuxer]") || line.contains("Merging formats")) {
            t.phase = "Finishing"
        }
        var pc = p
        if (pc < 0f) {
            val m = RX_AP.find(line)
            if (m != null) pc = m.groupValues[1].toFloat()
        }
        if (pc >= 0f) {
            val v = if (t.merge && t.kind == "v") {
                if (t.stage <= 1) pc * 0.92f else 92f + pc * 0.08f
            } else pc
            if (v >= t.pct) t.pct = v
        }
        val m1 = RX_YT.find(line) ?: RX_AR.find(line)
        if (m1 != null) {
            val num = m1.groupValues[1].toDoubleOrNull()
            if (num != null) t.speed = num * mult(m1.groupValues[2])
        }
        if (e >= 0L) t.eta = e
        push()
    }

    private fun runOnce(t: Task, dir: File, aria: Boolean, useInfo: Boolean) {
        t.stage = 0
        t.phase = ""
        val req = Engine.request(t, dir, aria, useInfo)
        YoutubeDL.getInstance().execute(req, t.id) { p, e, l ->
            onLine(t, p, e, l)
        }
    }

    private fun isTransient(e: Exception): Boolean {
        val m = (e.message ?: "").lowercase()
        return m.contains("timed out") || m.contains("connection") || m.contains("reset") ||
            m.contains("unreachable") || m.contains("temporar") || m.contains("http error 5")
    }

    private fun clean(e: Exception): String {
        val m = e.message ?: "Download failed"
        val lines = m.lines()
        val line = lines.lastOrNull { it.contains("ERROR") } ?: lines.lastOrNull { it.isNotBlank() } ?: m
        return line.replace("ERROR:", "").replace(Regex("""\[\w+\]\s*"""), "").trim().take(110)
    }

    private fun run(t: Task) {
        val dir = File(base, "dl/" + t.id)
        try {
            Engine.await()
            dir.mkdirs()
            var aria = Prefs.turbo && Engine.aria
            var useInfo = true
            var tries = 0
            while (true) {
                try {
                    runOnce(t, dir, aria, useInfo)
                    break
                } catch (e: Exception) {
                    if (t.state != "r") return
                    tries++
                    if (aria) {
                        aria = false
                        continue
                    }
                    if (useInfo && t.infoFile != null) {
                        useInfo = false
                        continue
                    }
                    if (tries < 4 && isTransient(e)) {
                        Thread.sleep(1200)
                        continue
                    }
                    throw e
                }
            }
            if (t.state != "r") return
            val f = dir.listFiles()
                ?.filter { it.isFile && MIMES.containsKey(it.extension.lowercase()) }
                ?.maxByOrNull { it.length() }
                ?: throw Exception("No file was produced")
            t.phase = "Saving"
            push()
            val item = saveToStore(f, t)
            dir.deleteRecursively()
            synchronized(lock) {
                tasks.remove(t)
                lib.add(0, item)
            }
            persistTasks()
            persistLib()
            val o = item.ui()
            U.main.post {
                listener?.onDone(o)
                listener?.onLib(libJson())
            }
            push()
            Notifs.done(app, item)
        } catch (e: Exception) {
            if (t.state == "r") {
                t.state = "f"
                t.err = clean(e)
                persistTasks()
            }
        } finally {
            schedule()
        }
    }

    private fun saveToStore(f: File, t: Task): Item {
        val ext = f.extension.lowercase()
        val mime = MIMES[ext] ?: "application/octet-stream"
        val cv = ContentValues()
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
        cv.put(MediaStore.MediaColumns.MIME_TYPE, mime)
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/BoxTube")
        cv.put(MediaStore.MediaColumns.IS_PENDING, 1)
        val res = app.contentResolver
        val uri = res.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: throw Exception("Cannot create file")
        res.openOutputStream(uri)!!.use { o -> f.inputStream().use { i -> i.copyTo(o, 256 * 1024) } }
        val fin = ContentValues()
        fin.put(MediaStore.MediaColumns.IS_PENDING, 0)
        res.update(uri, fin, null, null)
        val id = "m" + ContentUris.parseId(uri)
        val audio = mime.startsWith("audio")
        Thumbs.make(id, t.thumb, f, audio)
        return Item(id, f.nameWithoutExtension, uri.toString(), mime, if (audio) "a" else "v", f.length(), t.dur, t.thumb, t.who, System.currentTimeMillis())
    }

    // ---------------------------------------------------------------- library
    /** Library = files in Download/BoxTube (works after reinstall too). */
    fun syncLib() {
        try {
            val have = HashMap<String, Item>()
            synchronized(lock) { for (x in lib) have[x.uri] = x }
            val found = ArrayList<Item>()
            val base = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val sel = MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?"
            val args = arrayOf("Download/BoxTube%")
            val order = MediaStore.MediaColumns.DATE_ADDED + " DESC"
            val full = arrayOf(
                MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE,
                MediaStore.MediaColumns.MIME_TYPE, MediaStore.MediaColumns.DATE_ADDED, MediaStore.MediaColumns.DURATION
            )
            val c = try {
                app.contentResolver.query(base, full, sel, args, order)
            } catch (e: Exception) {
                app.contentResolver.query(base, full.copyOf(5).requireNoNulls(), sel, args, order)
            }
            if (c != null) {
                c.use {
                    while (it.moveToNext()) {
                        val id = it.getLong(0)
                        val uri = ContentUris.withAppendedId(base, id).toString()
                        val ex = have[uri]
                        if (ex != null) {
                            found.add(ex)
                            continue
                        }
                        val name = it.getString(1) ?: continue
                        val mime = it.getString(3) ?: "application/octet-stream"
                        val k = if (mime.startsWith("audio")) "a" else "v"
                        val d = if (it.columnCount > 5) it.getLong(5) / 1000 else 0L
                        found.add(Item("m$id", name.substringBeforeLast('.'), uri, mime, k, it.getLong(2), d, "", "", it.getLong(4) * 1000))
                    }
                }
                synchronized(lock) {
                    lib.clear()
                    lib.addAll(found)
                }
                persistLib()
                U.main.post { listener?.onLib(libJson()) }
            }
        } catch (e: Exception) {
        }
    }

    fun delete(id: String): Boolean {
        val x = findItem(id) ?: return false
        try {
            app.contentResolver.delete(Uri.parse(x.uri), null, null)
        } catch (e: Exception) {
        }
        synchronized(lock) { lib.remove(x) }
        File(Thumbs.dir, "$id.jpg").delete()
        persistLib()
        return true
    }

    fun playIntent(c: Context, list: List<Item>, idx: Int): Intent {
        val i = Intent(c, PlayerActivity::class.java)
        i.putExtra("uris", Array(list.size) { list[it].uri })
        i.putExtra("titles", Array(list.size) { list[it].title })
        i.putExtra("kinds", Array(list.size) { list[it].kind })
        i.putExtra("thumbs", Array(list.size) { n ->
            val f = File(Thumbs.dir, list[n].id + ".jpg")
            if (f.exists()) f.absolutePath else ""
        })
        i.putExtra("index", idx)
        return i
    }
}
