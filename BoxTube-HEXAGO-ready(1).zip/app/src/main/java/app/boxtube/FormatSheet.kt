package app.boxtube

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

private class Opt(
    val kind: String,
    val res: String,
    val title: String,
    val sub: String,
    val size: Long,
    val tag: String,
    val merge: Boolean,
    val h: Int
)

/** ScrollView that never grows taller than [maxH]. */
class MaxScroll(c: Context, private val maxH: Int) : ScrollView(c) {
    override fun onMeasure(w: Int, h: Int) {
        super.onMeasure(w, View.MeasureSpec.makeMeasureSpec(maxH, View.MeasureSpec.AT_MOST))
    }
}

/**
 * Quality picker. Opens instantly with the title/thumbnail it already knows,
 * then fills in formats as soon as the engine answers (often already prefetched).
 */
class FormatSheet(
    private val act: Activity,
    private val host: FrameLayout,
    private val onView: () -> Unit
) {
    var showing = false
        private set

    private var root: FrameLayout? = null
    private var panel: LinearLayout? = null
    private var body: LinearLayout? = null
    private var thumbView: ImageView? = null
    private var titleView: TextView? = null
    private var subView: TextView? = null
    private var skel: ObjectAnimator? = null
    private var token = 0
    private var url = ""
    private var info: Info? = null
    private var opts = ArrayList<Opt>()
    private val rows = ArrayList<LinearLayout>()
    private var sel = 0
    private var dlBtn: TextView? = null
    private var hTitle = ""
    private var hThumb = ""
    private var hDur = 0L
    private var hWho = ""

    private fun dp(v: Int): Int = U.dp(act, v)

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(act)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD)
        return t
    }

    fun show(u: String, title: String, thumb: String, dur: Long, who: String) {
        if (showing) dismissNow()
        url = u
        hTitle = title
        hThumb = thumb
        hDur = dur
        hWho = who
        info = null
        token++
        val my = token
        build()
        showing = true
        renderLoading()
        U.io.execute {
            try {
                val i = Engine.info(u, Engine.cookies(u))
                U.main.post { if (my == token && showing) renderInfo(i) }
            } catch (e: Exception) {
                val m = e.message ?: "Unknown error"
                U.main.post { if (my == token && showing) renderError(m) }
            }
        }
    }

    fun dismiss() {
        if (!showing) return
        showing = false
        token++
        stopSkel()
        val r = root ?: return
        val p = panel
        r.animate().alpha(0f).setDuration(140).start()
        if (p != null) {
            p.animate().translationY(dp(520).toFloat()).setDuration(180).withEndAction { host.removeView(r) }.start()
        } else {
            host.removeView(r)
        }
        root = null
    }

    private fun dismissNow() {
        val r = root
        if (r != null) host.removeView(r)
        root = null
        showing = false
        token++
        stopSkel()
    }

    // ------------------------------------------------------------------ build
    private fun build() {
        val r = FrameLayout(act)
        r.setBackgroundColor(0x99000000.toInt())
        r.alpha = 0f
        r.setOnClickListener { dismiss() }

        val sheet = LinearLayout(act)
        sheet.orientation = LinearLayout.VERTICAL
        sheet.background = U.topRound(C.sf, dp(26).toFloat())
        sheet.setPadding(dp(18), dp(10), dp(18), dp(18))
        sheet.isClickable = true

        val handle = View(act)
        handle.background = U.shape(0xFF2F3550.toInt(), dp(3).toFloat())
        val hp = LinearLayout.LayoutParams(dp(40), dp(5))
        hp.gravity = Gravity.CENTER_HORIZONTAL
        hp.bottomMargin = dp(12)
        sheet.addView(handle, hp)

        val head = LinearLayout(act)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val th = ImageView(act)
        th.scaleType = ImageView.ScaleType.CENTER_CROP
        th.setBackgroundColor(C.sf2)
        U.clip(th, dp(12).toFloat())
        thumbView = th
        head.addView(th, LinearLayout.LayoutParams(dp(112), dp(63)))
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        val t1 = tv("", 15f, C.tx, true)
        t1.maxLines = 2
        t1.ellipsize = TextUtils.TruncateAt.END
        val t2 = tv("", 12f, C.mu)
        t2.maxLines = 1
        t2.ellipsize = TextUtils.TruncateAt.END
        titleView = t1
        subView = t2
        col.addView(t1)
        col.addView(t2)
        val cp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        cp.leftMargin = dp(12)
        head.addView(col, cp)
        sheet.addView(head)

        val b = LinearLayout(act)
        b.orientation = LinearLayout.VERTICAL
        body = b
        sheet.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        r.addView(sheet, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        host.addView(r, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root = r
        panel = sheet
        sheet.translationY = dp(520).toFloat()
        r.animate().alpha(1f).setDuration(160).start()
        sheet.animate().translationY(0f).setDuration(240).setInterpolator(DecelerateInterpolator()).start()
        applyHeader(hTitle, hWho, hDur, hThumb)
    }

    private fun applyHeader(title: String, who: String, dur: Long, thumb: String) {
        titleView?.text = if (title.isEmpty()) "Reading link…" else title
        val d = U.dur(dur)
        subView?.text = if (who.isNotEmpty() && d.isNotEmpty()) "$who · $d" else if (who.isNotEmpty()) who else d
        val iv = thumbView
        if (iv != null && thumb.isNotEmpty() && iv.tag != thumb) Img.load(thumb, iv)
    }

    private fun stopSkel() {
        skel?.cancel()
        skel = null
        body?.alpha = 1f
    }

    private fun label(t: String): TextView {
        val l = tv(t, 11f, C.mu, true)
        l.letterSpacing = 0.08f
        l.setPadding(dp(2), dp(14), 0, 0)
        return l
    }

    private fun bigButton(text: String): TextView {
        val b = tv(text, 16f, 0xFFFFFFFF.toInt(), true)
        b.gravity = Gravity.CENTER
        b.background = U.shape(C.ac, dp(16).toFloat())
        return b
    }

    private fun iconButton(res: Int): ImageView {
        val v = ImageView(act)
        v.setImageResource(res)
        v.setColorFilter(0xFFAFC0FF.toInt())
        v.setPadding(dp(15), dp(15), dp(15), dp(15))
        v.background = U.shape(0xFF1B2252.toInt(), dp(16).toFloat())
        return v
    }

    // ----------------------------------------------------------------- states
    private fun renderLoading() {
        val b = body ?: return
        b.removeAllViews()
        for (i in 0 until 3) {
            val v = View(act)
            v.background = U.shape(C.sf2, dp(14).toFloat())
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54))
            lp.topMargin = dp(8)
            b.addView(v, lp)
        }
        val btn = bigButton("Download")
        btn.alpha = 0.35f
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52))
        lp.topMargin = dp(18)
        b.addView(btn, lp)
        val a = ObjectAnimator.ofFloat(b, "alpha", 0.45f, 1f)
        a.duration = 700
        a.repeatCount = ValueAnimator.INFINITE
        a.repeatMode = ValueAnimator.REVERSE
        a.start()
        skel = a
    }

    private fun renderError(msg: String) {
        stopSkel()
        val b = body ?: return
        b.removeAllViews()
        val e = tv(msg, 14f, C.red)
        e.setPadding(0, dp(16), 0, dp(4))
        b.addView(e)
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        val retry = bigButton("Try again")
        retry.setOnClickListener { show(url, hTitle, hThumb, hDur, hWho) }
        val close = bigButton("Close")
        close.background = U.shape(0xFF1B2252.toInt(), dp(16).toFloat())
        close.setTextColor(0xFFAFC0FF.toInt())
        close.setOnClickListener { dismiss() }
        val l1 = LinearLayout.LayoutParams(0, dp(52), 1f)
        val l2 = LinearLayout.LayoutParams(0, dp(52), 1f)
        l2.leftMargin = dp(10)
        row.addView(retry, l1)
        row.addView(close, l2)
        val rl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        rl.topMargin = dp(12)
        b.addView(row, rl)
    }

    private fun labelOf(h: Int): String = when {
        h >= 4320 -> "8K"
        h >= 2160 -> "Ultra 4K"
        h >= 1440 -> "2K QHD"
        h >= 1080 -> "Full HD"
        h >= 720 -> "High quality"
        h >= 480 -> "Standard"
        else -> "Fast"
    }

    private fun buildOpts(i: Info): ArrayList<Opt> {
        val o = ArrayList<Opt>()
        val hs = i.video.map { it.h }
        val best = if (hs.contains(720)) 720 else (hs.lastOrNull { it <= 720 } ?: (hs.firstOrNull() ?: 0))
        for (v in i.video) {
            o.add(Opt("v", v.h.toString(), labelOf(v.h), v.h.toString() + "p · MP4", v.size, if (v.h == best) "Best pick" else "", v.merge, v.h))
        }
        if (i.video.isEmpty()) o.add(Opt("v", "720", "Best quality", "MP4", 0L, "Best pick", true, 720))
        o.add(Opt("a", "m4a", "Fast audio", "M4A · AAC", i.audioSize, "", false, 0))
        o.add(Opt("a", "mp3", "Classic MP3", "MP3 · best quality", i.dur * 30625L, "", false, 0))
        return o
    }

    private fun renderInfo(i: Info) {
        stopSkel()
        info = i
        val b = body ?: return
        b.removeAllViews()
        rows.clear()
        applyHeader(i.title, i.who, i.dur, i.thumb)
        opts = buildOpts(i)
        sel = maxOf(0, opts.indexOfFirst { it.tag == "Best pick" })

        val list = LinearLayout(act)
        list.orientation = LinearLayout.VERTICAL
        var lastKind = ""
        for (idx in opts.indices) {
            val o = opts[idx]
            if (o.kind != lastKind) {
                list.addView(label(if (o.kind == "v") "VIDEO" else "MUSIC"))
                lastKind = o.kind
            }
            val rv = row(o, idx)
            rows.add(rv)
            list.addView(rv)
        }
        val sc = MaxScroll(act, (act.resources.displayMetrics.heightPixels * 0.42f).toInt())
        sc.isVerticalScrollBarEnabled = false
        sc.addView(list)
        b.addView(sc, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val btns = LinearLayout(act)
        btns.orientation = LinearLayout.HORIZONTAL
        val dl = bigButton("Download")
        dl.setOnClickListener { start(false) }
        dlBtn = dl
        val play = iconButton(R.drawable.ic_play)
        play.setOnClickListener { playNow() }
        val later = iconButton(R.drawable.ic_clock)
        later.setOnClickListener { start(true) }
        btns.addView(dl, LinearLayout.LayoutParams(0, dp(52), 1f))
        val pl = LinearLayout.LayoutParams(dp(52), dp(52))
        pl.leftMargin = dp(10)
        btns.addView(play, pl)
        btns.addView(later, pl)
        val bl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        bl.topMargin = dp(16)
        b.addView(btns, bl)
        refresh()
    }

    private fun row(o: Opt, idx: Int): LinearLayout {
        val r = LinearLayout(act)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(12), 0, dp(14), 0)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56))
        lp.topMargin = dp(8)
        r.layoutParams = lp

        val ico = ImageView(act)
        ico.setImageResource(if (o.kind == "v") R.drawable.ic_video else R.drawable.ic_music)
        ico.setColorFilter(0xFFAFC0FF.toInt())
        ico.setPadding(dp(8), dp(8), dp(8), dp(8))
        ico.background = U.shape(0xFF1B2252.toInt(), dp(11).toFloat())
        r.addView(ico, LinearLayout.LayoutParams(dp(36), dp(36)))

        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        val t1 = LinearLayout(act)
        t1.orientation = LinearLayout.HORIZONTAL
        t1.gravity = Gravity.CENTER_VERTICAL
        t1.addView(tv(o.title, 15f, C.tx, true))
        if (o.tag.isNotEmpty()) {
            val pill = tv(o.tag, 10f, C.lime, true)
            pill.setPadding(dp(7), dp(1), dp(7), dp(1))
            pill.background = U.shape(0x24B6F24A, dp(8).toFloat())
            val pp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            pp.leftMargin = dp(8)
            t1.addView(pill, pp)
        }
        col.addView(t1)
        col.addView(tv(o.sub, 12f, C.mu))
        val cp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        cp.leftMargin = dp(12)
        r.addView(col, cp)

        r.addView(tv(if (o.size > 0L) "~" + U.size(o.size) else "", 13f, 0xFFC9CFE3.toInt(), true))
        val rd = View(act)
        val rp = LinearLayout.LayoutParams(dp(22), dp(22))
        rp.leftMargin = dp(12)
        r.addView(rd, rp)
        r.tag = rd
        r.setOnClickListener {
            sel = idx
            refresh()
        }
        return r
    }

    private fun refresh() {
        for (i in rows.indices) {
            val r = rows[i]
            val on = i == sel
            r.background = if (on) U.shape(0xFF141A3D.toInt(), dp(14).toFloat(), C.ac, dp(2))
            else U.shape(0xFF151824.toInt(), dp(14).toFloat(), C.bd, dp(1))
            val rd = r.tag as View
            val g = U.oval(if (on) C.ac else 0x00000000)
            g.setStroke(dp(2), if (on) C.ac else 0xFF4A5068.toInt())
            rd.background = g
        }
        val o = opts.getOrNull(sel)
        if (o != null) {
            val s = if (o.size > 0L) " · ~" + U.size(o.size) else ""
            dlBtn?.text = "Download$s"
        }
    }

    // ---------------------------------------------------------------- actions
    private fun start(later: Boolean) {
        val i = info ?: return
        val o = opts.getOrNull(sel) ?: return
        U.askNotif(act)
        Downloads.enqueue(i, url, i.title, i.who, i.thumb, i.dur, o.kind, o.res, o.merge, later, Engine.cookies(url))
        dismiss()
        Snack.show(host, if (later) "Added to queue" else "Download started", "View", { onView() })
    }

    private fun playNow() {
        val i = info ?: return
        val o = opts.getOrNull(sel) ?: return
        val intent = Intent(act, PlayerActivity::class.java)
        intent.putExtra("page", url)
        intent.putExtra("h", if (o.kind == "a") 0 else o.h)
        intent.putExtra("title", i.title)
        intent.putExtra("thumb", i.thumb)
        act.startActivity(intent)
    }
}
