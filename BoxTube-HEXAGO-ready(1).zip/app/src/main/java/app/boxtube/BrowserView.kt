package app.boxtube

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.io.ByteArrayInputStream

/**
 * Full-screen in-app browser. A floating download button wakes up (pulses) when a
 * downloadable video is detected on the page, just like Snaptube / VidMate.
 */
@SuppressLint("SetJavaScriptEnabled", "ViewConstructor")
class BrowserView(private val act: Activity, private val cb: Cb) : FrameLayout(act) {

    interface Cb {
        fun onClose()
        fun onAnalyze(url: String)
        fun onToast(m: String)
    }

    val wv = WebView(act)
    private val addr = EditText(act)
    private val prog = View(act)
    private val lock = ImageView(act)
    private val reload = ImageView(act)
    private val col = LinearLayout(act)
    private val fs = FrameLayout(act)
    private val fab = FrameLayout(act)
    private val ring = View(act)
    private val fabBtn = ImageView(act)
    private val badge = TextView(act)

    private var cur = ""
    private var sniffed: String? = null
    private var hasVideo = false
    private var detected = false
    private var loading = false
    private var pulse: ObjectAnimator? = null
    private var custom: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private val bgOn: GradientDrawable
    private val bgOff: GradientDrawable
    private val prefetchRun = Runnable { if (isVideoUrl(cur)) Engine.prefetch(cur) }

    val isOpen: Boolean get() = visibility == View.VISIBLE

    private fun dp(v: Int): Int = U.dp(act, v)

    init {
        visibility = View.GONE
        setBackgroundColor(C.bg)

        col.orientation = LinearLayout.VERTICAL

        // ---- top bar
        val top = LinearLayout(act)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.setBackgroundColor(C.bg)
        top.setPadding(dp(4), dp(6), dp(4), dp(6))

        val close = icon(R.drawable.ic_close) { cb.onClose() }
        top.addView(close, LinearLayout.LayoutParams(dp(42), dp(42)))

        val pill = LinearLayout(act)
        pill.orientation = LinearLayout.HORIZONTAL
        pill.gravity = Gravity.CENTER_VERTICAL
        pill.background = U.shape(C.sf, dp(21).toFloat())
        pill.setPadding(dp(12), 0, dp(6), 0)
        lock.setImageResource(R.drawable.ic_lock)
        lock.setColorFilter(C.lime)
        pill.addView(lock, LinearLayout.LayoutParams(dp(14), dp(14)))
        addr.setSingleLine(true)
        addr.setHint("Search or enter URL")
        addr.setHintTextColor(C.dm)
        addr.setTextColor(C.tx)
        addr.textSize = 14f
        addr.background = null
        addr.setPadding(dp(8), 0, dp(8), 0)
        addr.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        addr.imeOptions = EditorInfo.IME_ACTION_GO
        addr.setSelectAllOnFocus(true)
        addr.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                go(v.text.toString())
                true
            } else false
        }
        addr.setOnFocusChangeListener { _, f ->
            if (f) {
                addr.setText(cur)
                addr.selectAll()
            } else addr.setText(U.host(cur))
        }
        pill.addView(addr, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        top.addView(pill, LinearLayout.LayoutParams(0, dp(42), 1f))

        reload.setImageResource(R.drawable.ic_reload)
        reload.setColorFilter(C.tx)
        reload.setPadding(dp(10), dp(10), dp(10), dp(10))
        reload.setOnClickListener { if (loading) wv.stopLoading() else wv.reload() }
        top.addView(reload, LinearLayout.LayoutParams(dp(42), dp(42)))
        col.addView(top, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // ---- progress bar
        prog.setBackgroundColor(C.ac)
        prog.pivotX = 0f
        prog.scaleX = 0f
        col.addView(prog, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2)))

        // ---- web view
        setupWeb()
        col.addView(wv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // ---- floating download button
        bgOn = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(C.ac, C.ac2))
        bgOn.setShape(GradientDrawable.OVAL)
        bgOff = U.oval(0xFF2A3045.toInt())
        ring.background = U.oval(0x664361FF)
        ring.visibility = View.GONE
        fab.addView(ring, FrameLayout.LayoutParams(dp(58), dp(58)))
        fabBtn.setImageResource(R.drawable.ic_download)
        fabBtn.setColorFilter(0xFFFFFFFF.toInt())
        fabBtn.setPadding(dp(16), dp(16), dp(16), dp(16))
        fabBtn.background = bgOff
        fabBtn.elevation = dp(6).toFloat()
        fab.addView(fabBtn, FrameLayout.LayoutParams(dp(58), dp(58)))
        badge.text = "1"
        badge.textSize = 10f
        badge.setTextColor(0xFF000000.toInt())
        badge.setTypeface(Typeface.DEFAULT_BOLD)
        badge.gravity = Gravity.CENTER
        badge.background = U.oval(C.lime)
        badge.visibility = View.GONE
        badge.elevation = dp(8).toFloat()
        val bp = FrameLayout.LayoutParams(dp(18), dp(18))
        bp.gravity = Gravity.TOP or Gravity.END
        fab.addView(badge, bp)
        fab.setOnClickListener { onFab() }
        val fp = FrameLayout.LayoutParams(dp(58), dp(58), Gravity.BOTTOM or Gravity.END)
        fp.setMargins(0, 0, dp(18), dp(28))
        addView(fab, fp)

        // ---- full screen video holder
        fs.setBackgroundColor(0xFF000000.toInt())
        fs.visibility = View.GONE
        addView(fs, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    private fun icon(res: Int, onClick: () -> Unit): ImageView {
        val v = ImageView(act)
        v.setImageResource(res)
        v.setColorFilter(C.tx)
        v.setPadding(dp(10), dp(10), dp(10), dp(10))
        v.setOnClickListener { onClick() }
        return v
    }

    // ---------------------------------------------------------------- web view
    private fun setupWeb() {
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.setSupportMultipleWindows(false)
        s.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.userAgentString = s.userAgentString.replace("; wv", "").replace("Version/4.0 ", "")
        wv.setBackgroundColor(C.bg)
        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(wv, true)

        wv.setDownloadListener { u, _, _, _, _ -> cb.onAnalyze(u) }

        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val sc = r.url.scheme ?: ""
                return !(sc == "http" || sc == "https" || sc == "about" || sc == "data" || sc == "blob")
            }

            override fun onPageStarted(v: WebView, url: String?, f: Bitmap?) {
                val u = url ?: ""
                if (u != cur) {
                    sniffed = null
                    hasVideo = false
                }
                setLoading(true)
                urlChanged(u)
            }

            override fun onPageFinished(v: WebView, url: String?) {
                setLoading(false)
                urlChanged(url ?: "")
                probe()
            }

            override fun doUpdateVisitedHistory(v: WebView, url: String?, isReload: Boolean) {
                urlChanged(url ?: "")
            }

            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val u = r.url.toString()
                val host = r.url.host ?: ""
                if (Prefs.adblock && isAd(host, u)) {
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                sniff(u)
                return null
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                prog.animate().scaleX(p / 100f).setDuration(120).start()
                prog.alpha = if (p >= 100) 0f else 1f
            }

            override fun onShowCustomView(view: View, c: WebChromeClient.CustomViewCallback) {
                showFull(view, c)
            }

            override fun onHideCustomView() {
                hideFull()
            }
        }
    }

    // ------------------------------------------------------------------ logic
    private fun go(raw: String) {
        val s = raw.trim()
        if (s.isEmpty()) return
        val u = when {
            Regex("^https?://\\S+$").matches(s) -> s
            Regex("^[\\w-]+(\\.[\\w-]+)+(/\\S*)?$").matches(s) -> "https://" + s
            else -> "https://www.google.com/search?q=" + Uri.encode(s)
        }
        wv.loadUrl(u)
        addr.clearFocus()
        val imm = act.getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(addr.windowToken, 0)
    }

    private fun setLoading(on: Boolean) {
        loading = on
        reload.setImageResource(if (on) R.drawable.ic_close else R.drawable.ic_reload)
        if (on) {
            prog.alpha = 1f
            prog.scaleX = 0.08f
        }
    }

    private fun urlChanged(u: String) {
        if (u.isEmpty() || u == cur) return
        cur = u
        if (!addr.hasFocus()) addr.setText(U.host(u))
        lock.visibility = if (u.startsWith("https")) View.VISIBLE else View.GONE
        if (isVideoUrl(u)) {
            setDetected(true)
            U.main.removeCallbacks(prefetchRun)
            U.main.postDelayed(prefetchRun, 700)
        } else if (sniffed == null && !hasVideo) {
            setDetected(false)
        }
    }

    private fun probe() {
        if (!isKnownHost(cur)) {
            wv.evaluateJavascript("(function(){var v=document.querySelector('video');return v?1:0})()") { r ->
                if (r == "1") {
                    hasVideo = true
                    setDetected(true)
                }
            }
        }
        if (Prefs.adblock && U.host(cur).contains("youtube.com")) wv.evaluateJavascript(AD_JS, null)
    }

    private fun sniff(u: String) {
        val p = u.substringBefore('?').lowercase()
        if (p.endsWith(".mp4") || p.endsWith(".m3u8") || p.endsWith(".webm") || p.endsWith(".mp3") ||
            p.endsWith(".m4a") || p.endsWith(".mpd") || p.endsWith(".m4v")
        ) {
            U.main.post {
                sniffed = u
                setDetected(true)
            }
        }
    }

    private fun setDetected(on: Boolean) {
        if (detected == on) return
        detected = on
        fabBtn.background = if (on) bgOn else bgOff
        badge.visibility = if (on) View.VISIBLE else View.GONE
        if (on) {
            startPulse()
            fab.animate().scaleX(1.14f).scaleY(1.14f).setDuration(140).withEndAction {
                fab.animate().scaleX(1f).scaleY(1f).setDuration(180).start()
            }.start()
        } else stopPulse()
    }

    private fun startPulse() {
        ring.visibility = View.VISIBLE
        val a = ObjectAnimator.ofPropertyValuesHolder(
            ring,
            PropertyValuesHolder.ofFloat("scaleX", 1f, 1.7f),
            PropertyValuesHolder.ofFloat("scaleY", 1f, 1.7f),
            PropertyValuesHolder.ofFloat("alpha", 0.55f, 0f)
        )
        a.duration = 1400
        a.repeatCount = ValueAnimator.INFINITE
        a.start()
        pulse = a
    }

    private fun stopPulse() {
        pulse?.cancel()
        pulse = null
        ring.visibility = View.GONE
    }

    private fun onFab() {
        val u: String? = if (isVideoUrl(cur)) cur else (sniffed ?: if (hasVideo) cur else null)
        if (u == null) cb.onToast("Open a video first, then tap this button")
        else cb.onAnalyze(u)
    }

    // ------------------------------------------------------------- lifecycle
    fun open(u: String) {
        if (visibility != View.VISIBLE) {
            visibility = View.VISIBLE
            alpha = 0f
            translationY = dp(28).toFloat()
            animate().alpha(1f).translationY(0f).setDuration(200).start()
        }
        wv.onResume()
        wv.resumeTimers()
        if (u.isNotEmpty() && u != wv.url) wv.loadUrl(u)
    }

    fun close() {
        if (custom != null) hideFull()
        wv.evaluateJavascript("document.querySelectorAll('video,audio').forEach(function(v){v.pause()})", null)
        U.main.postDelayed({ if (!isOpen) wv.onPause() }, 400)
        animate().alpha(0f).translationY(dp(28).toFloat()).setDuration(160).withEndAction {
            visibility = View.GONE
            alpha = 1f
            translationY = 0f
        }.start()
        val imm = act.getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(windowToken, 0)
    }

    /** Back key: returns true when the browser handled it. */
    fun back(): Boolean {
        if (custom != null) {
            hideFull()
            return true
        }
        if (wv.canGoBack()) {
            wv.goBack()
            return true
        }
        return false
    }

    fun hostPause() {
        if (isOpen) wv.onPause()
    }

    fun hostResume() {
        if (isOpen) wv.onResume()
    }

    // ------------------------------------------------------ full screen video
    @Suppress("DEPRECATION")
    private fun showFull(v: View, c: WebChromeClient.CustomViewCallback) {
        if (custom != null) {
            c.onCustomViewHidden()
            return
        }
        custom = v
        customCb = c
        fs.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        fs.visibility = View.VISIBLE
        fab.visibility = View.GONE
        act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        act.window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }

    @Suppress("DEPRECATION")
    private fun hideFull() {
        val v = custom ?: return
        fs.removeView(v)
        fs.visibility = View.GONE
        fab.visibility = View.VISIBLE
        customCb?.onCustomViewHidden()
        custom = null
        customCb = null
        act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        act.window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
    }

    companion object {
        private val VID = Regex(
            """^https?://([\w-]+\.)*(youtube\.com/(watch|shorts/|live/|embed/)|youtu\.be/|facebook\.com/(watch|reel/|[^/]+/videos/|share/(v|r)/|video\.php)|fb\.watch/|instagram\.com/(reel|reels|p|tv)/|tiktok\.com/(@[^/]+/video/|v/)|vm\.tiktok\.com/|vt\.tiktok\.com/|(twitter|x)\.com/[^/]+/status/|vimeo\.com/\d+|dailymotion\.com/video/|dai\.ly/|soundcloud\.com/[^/]+/[^/]+|bilibili\.com/video/|reddit\.com/r/[^/]+/comments/|twitch\.tv/(videos/|[^/]+/clip/)|rumble\.com/v)""",
            RegexOption.IGNORE_CASE
        )
        private val KNOWN = arrayOf(
            "youtube.com", "youtu.be", "facebook.com", "fb.watch", "instagram.com", "tiktok.com",
            "twitter.com", "x.com", "vimeo.com", "dailymotion.com", "soundcloud.com", "reddit.com", "twitch.tv"
        )
        private val AD_HOSTS = arrayOf(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
            "googletagservices.com", "google-analytics.com", "adnxs.com", "taboola.com", "outbrain.com",
            "moatads.com", "scorecardresearch.com", "popads.net", "propellerads.com", "exoclick.com",
            "juicyads.com", "trafficjunky.com", "adsterra.com", "hilltopads.net", "mgid.com", "revcontent.com",
            "amazon-adsystem.com", "criteo.com", "pubmatic.com", "rubiconproject.com", "openx.net",
            "smartadserver.com", "adcolony.com", "applovin.com", "unityads.unity3d.com"
        )
        private val AD_PATHS = arrayOf(
            "youtube.com/pagead/", "youtube.com/api/stats/ads", "youtube.com/ptracking",
            "youtube.com/get_midroll_info", "youtube.com/api/stats/atr"
        )
        private const val AD_JS = "(function(){if(window.__bt)return;window.__bt=1;setInterval(function(){try{" +
            "var b=document.querySelector('.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button');if(b)b.click();" +
            "var p=document.querySelector('.html5-video-player');" +
            "if(p&&p.classList.contains('ad-showing')){var v=document.querySelector('video');" +
            "if(v&&isFinite(v.duration)&&v.duration>0){v.muted=true;v.currentTime=v.duration;}}" +
            "document.querySelectorAll('.ytp-ad-overlay-container,ytm-promoted-sparkles-web-renderer,ytd-promoted-sparkles-web-renderer,ytm-companion-ad-renderer')" +
            ".forEach(function(e){e.style.display='none'});}catch(e){}},400)})();"

        fun isVideoUrl(u: String): Boolean = VID.containsMatchIn(u)

        fun isKnownHost(u: String): Boolean {
            val h = U.host(u)
            return KNOWN.any { h == it || h.endsWith(".$it") }
        }

        fun isAd(host: String, u: String): Boolean {
            if (AD_HOSTS.any { host == it || host.endsWith(".$it") }) return true
            return AD_PATHS.any { u.contains(it) }
        }
    }
}
