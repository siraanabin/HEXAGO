package app.boxtube

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.Locale
import java.util.concurrent.Executors

/** Brand colours used by the native screens (browser, sheet, player). */
object C {
    val bg = 0xFF090B12.toInt()
    val sf = 0xFF121623.toInt()
    val sf2 = 0xFF1A2032.toInt()
    val bd = 0xFF232A3D.toInt()
    val tx = 0xFFF3F5FA.toInt()
    val mu = 0xFF98A2B8.toInt()
    val dm = 0xFF69728A.toInt()
    val ac = 0xFF4361FF.toInt()
    val ac2 = 0xFF8B5CFF.toInt()
    val lime = 0xFFB6F24A.toInt()
    val red = 0xFFFF5468.toInt()
}

object U {
    val main = Handler(Looper.getMainLooper())
    val io = Executors.newFixedThreadPool(4)

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun shape(color: Int, r: Float, strokeColor: Int = 0, strokeW: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setShape(GradientDrawable.RECTANGLE)
        g.setColor(color)
        g.setCornerRadius(r)
        if (strokeW > 0) g.setStroke(strokeW, strokeColor)
        return g
    }

    fun topRound(color: Int, r: Float): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.setCornerRadii(floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f))
        return g
    }

    fun oval(color: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setShape(GradientDrawable.OVAL)
        g.setColor(color)
        return g
    }

    fun clip(v: View, r: Float) {
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, r)
            }
        }
        v.clipToOutline = true
    }

    fun size(b: Long): String = when {
        b <= 0L -> ""
        b >= 1_000_000_000L -> String.format(Locale.US, "%.1f GB", b / 1e9)
        b >= 1_000_000L -> String.format(Locale.US, "%d MB", maxOf(1L, b / 1_000_000L))
        else -> String.format(Locale.US, "%d KB", maxOf(1L, b / 1000L))
    }

    fun dur(s: Long): String {
        if (s <= 0L) return ""
        val h = s / 3600
        val m = s % 3600 / 60
        val x = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, x) else String.format(Locale.US, "%d:%02d", m, x)
    }

    fun host(u: String): String = try { Uri.parse(u).host ?: "" } catch (e: Exception) { "" }

    fun md5(s: String): String {
        val d = MessageDigest.getInstance("MD5").digest(s.toByteArray())
        val sb = StringBuilder()
        for (b in d) sb.append(String.format("%02x", b))
        return sb.toString()
    }

    fun askNotif(a: Activity) {
        if (Build.VERSION.SDK_INT >= 33 && Prefs.notif &&
            a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            a.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
        }
    }
}

/** Tiny in-memory + network image loader (thumbnails in native screens). */
object Img {
    private val cache = object : LruCache<String, Bitmap>(20 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun load(url: String?, iv: ImageView, maxW: Int = 480) {
        if (url.isNullOrEmpty()) return
        iv.tag = url
        val hit = cache.get(url)
        if (hit != null) {
            iv.setImageBitmap(hit)
            return
        }
        U.io.execute {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 8000
                c.readTimeout = 8000
                val bytes = c.inputStream.use { it.readBytes() }
                val bo = BitmapFactory.Options()
                bo.inJustDecodeBounds = true
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bo)
                var s = 1
                while (bo.outWidth / (s * 2) >= maxW) s *= 2
                val o2 = BitmapFactory.Options()
                o2.inSampleSize = s
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
                if (bmp != null) {
                    cache.put(url, bmp)
                    U.main.post { if (iv.tag == url) iv.setImageBitmap(bmp) }
                }
            } catch (e: Exception) {
            }
        }
    }

    fun loadFile(path: String, iv: ImageView) {
        if (path.isEmpty()) return
        iv.tag = path
        U.io.execute {
            try {
                val o = BitmapFactory.Options()
                o.inSampleSize = 2
                val bmp = BitmapFactory.decodeFile(path, o)
                if (bmp != null) U.main.post { if (iv.tag == path) iv.setImageBitmap(bmp) }
            } catch (e: Exception) {
            }
        }
    }
}

/** Bottom message bar with an optional action ("View"). */
object Snack {
    fun show(parent: FrameLayout, msg: String, action: String? = null, onAction: (() -> Unit)? = null, bottomDp: Int = 24) {
        val c = parent.context
        val bar = LinearLayout(c)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.background = U.shape(0xFF1C2230.toInt(), U.dp(c, 16).toFloat(), 0xFF2F3850.toInt(), U.dp(c, 1))
        bar.setPadding(U.dp(c, 16), U.dp(c, 12), U.dp(c, 12), U.dp(c, 12))
        bar.elevation = U.dp(c, 8).toFloat()

        val t = TextView(c)
        t.text = msg
        t.setTextColor(C.tx)
        t.textSize = 14f
        t.maxLines = 2
        bar.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        if (action != null) {
            val a = TextView(c)
            a.text = action
            a.setTextColor(C.lime)
            a.textSize = 14f
            a.setTypeface(Typeface.DEFAULT_BOLD)
            a.setPadding(U.dp(c, 14), U.dp(c, 8), U.dp(c, 6), U.dp(c, 8))
            a.setOnClickListener {
                if (onAction != null) onAction()
                parent.removeView(bar)
            }
            bar.addView(a)
        }

        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        lp.setMargins(U.dp(c, 16), 0, U.dp(c, 16), U.dp(c, bottomDp))
        parent.addView(bar, lp)
        bar.translationY = U.dp(c, 40).toFloat()
        bar.alpha = 0f
        bar.animate().translationY(0f).alpha(1f).setDuration(220).start()
        U.main.postDelayed({
            bar.animate().alpha(0f).translationY(U.dp(c, 30).toFloat()).setDuration(200)
                .withEndAction { parent.removeView(bar) }.start()
        }, 3400)
    }
}

object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(c: Context) {
        sp = c.getSharedPreferences("bt", Context.MODE_PRIVATE)
    }

    fun bool(k: String, d: Boolean): Boolean = sp.getBoolean(k, d)
    fun int(k: String, d: Int): Int = sp.getInt(k, d)
    fun str(k: String, d: String): String = sp.getString(k, d) ?: d

    fun put(k: String, v: Any) {
        val e = sp.edit()
        if (v is Boolean) e.putBoolean(k, v)
        else if (v is Int) e.putInt(k, v)
        else e.putString(k, v.toString())
        e.apply()
    }

    val turbo: Boolean get() = bool("turbo", true)
    val parallel: Int get() = int("par", 2).coerceIn(1, 3)
    val wifiOnly: Boolean get() = bool("wifi", false)
    val notif: Boolean get() = bool("notif", true)
    val adblock: Boolean get() = bool("adblock", true)
    val bgplay: Boolean get() = bool("bg", false)
    val pip: Boolean get() = bool("pip", true)

    fun json(): JSONObject = JSONObject()
        .put("turbo", turbo).put("par", parallel).put("wifi", wifiOnly)
        .put("notif", notif).put("adblock", adblock).put("bg", bgplay).put("pip", pip)
}
