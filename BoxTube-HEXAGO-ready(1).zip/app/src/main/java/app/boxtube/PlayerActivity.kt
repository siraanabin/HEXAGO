package app.boxtube

import android.app.Activity
import android.app.AlertDialog
import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C as MC
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import org.json.JSONObject

/**
 * Built-in player: local files (playlist) or a stream resolved by the engine.
 * Double-tap = seek, swipe left side = brightness, right side = volume, PiP, speed, background audio.
 */
@androidx.annotation.OptIn(UnstableApi::class)
class PlayerActivity : Activity() {
    private var player: ExoPlayer? = null
    private lateinit var root: FrameLayout
    private lateinit var sv: SurfaceView
    private lateinit var art: FrameLayout
    private lateinit var artImg: ImageView
    private lateinit var spin: ProgressBar
    private lateinit var ctl: FrameLayout
    private lateinit var titleTv: TextView
    private lateinit var playBtn: ImageView
    private lateinit var seek: SeekBar
    private lateinit var curTv: TextView
    private lateinit var durTv: TextView
    private lateinit var speedTv: TextView
    private lateinit var hint: TextView
    private lateinit var errBox: LinearLayout
    private lateinit var errTv: TextView
    private lateinit var errBtn: TextView
    private lateinit var dlBtn: ImageView
    private lateinit var pipBtn: ImageView
    private var sheet: FormatSheet? = null

    private var uris: Array<String> = emptyArray()
    private var titles: Array<String> = emptyArray()
    private var kinds: Array<String> = emptyArray()
    private var thumbs: Array<String> = emptyArray()
    private var index = 0
    private var pageUrl = ""
    private var streamH = 0
    private var stream = false
    private var vw = 0f
    private var vh = 0f
    private var isAudio = false
    private var dragging = false
    private var ctlOn = true
    private var userBg = false
    private var rotated = false
    private var token = 0
    private val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
    private var speedIdx = 2
    private var volF = 0f

    private val tick = object : Runnable {
        override fun run() {
            updateProgress()
            U.main.postDelayed(this, 500)
        }
    }
    private val hideCtl = Runnable { showControls(false) }
    private val hideHint = Runnable { hint.visibility = View.GONE }

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            playBtn.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
            if (isPlaying) scheduleHide()
        }

        override fun onPlaybackStateChanged(state: Int) {
            spin.visibility = if (state == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
            val p = player ?: return
            if (state == Player.STATE_READY) {
                val d = p.duration
                if (d > 0L && d != MC.TIME_UNSET) {
                    seek.max = d.toInt()
                    durTv.text = tm(d)
                }
                errBox.visibility = View.GONE
            }
            if (state == Player.STATE_ENDED) showControls(true)
        }

        override fun onPlayerError(error: PlaybackException) {
            showMsg("Can't play this (" + error.errorCodeName + ")")
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            vw = videoSize.width * videoSize.pixelWidthHeightRatio
            vh = videoSize.height.toFloat()
            val hasVideo = videoSize.width > 0
            art.visibility = if (hasVideo) View.GONE else View.VISIBLE
            layoutSurface()
            if (hasVideo && !rotated && vw > vh && resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT) {
                rotated = true
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            }
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val p = player ?: return
            index = p.currentMediaItemIndex
            applyItemUi()
        }
    }

    // ----------------------------------------------------------------- create
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        buildUi()
        setContentView(root)
        immersive()
        readIntent(intent)
        startPlayer()
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        if (i.hasExtra("uris") || i.hasExtra("page")) {
            setIntent(i)
            token++
            readIntent(i)
            val p = player
            if (p != null) {
                p.stop()
                p.clearMediaItems()
            }
            if (stream) resolveStream() else loadLocal()
        }
    }

    private fun dp(v: Int): Int = U.dp(this, v)

    private fun readIntent(i: Intent) {
        val page = i.getStringExtra("page")
        if (page != null) {
            stream = true
            pageUrl = page
            streamH = i.getIntExtra("h", 720)
            titles = arrayOf(i.getStringExtra("title") ?: "")
            thumbs = arrayOf(i.getStringExtra("thumb") ?: "")
            kinds = arrayOf(if (streamH == 0) "a" else "v")
            uris = arrayOf("")
            index = 0
        } else {
            stream = false
            uris = i.getStringArrayExtra("uris") ?: emptyArray()
            titles = i.getStringArrayExtra("titles") ?: emptyArray()
            kinds = i.getStringArrayExtra("kinds") ?: emptyArray()
            thumbs = i.getStringArrayExtra("thumbs") ?: emptyArray()
            index = i.getIntExtra("index", 0).coerceIn(0, maxOf(0, uris.size - 1))
        }
    }

    // --------------------------------------------------------------------- ui
    private fun iconBtn(res: Int, size: Int, pad: Int, onClick: () -> Unit): ImageView {
        val v = ImageView(this)
        v.setImageResource(res)
        v.setColorFilter(0xFFFFFFFF.toInt())
        v.setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
        v.setOnClickListener {
            onClick()
            scheduleHide()
        }
        v.layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
        return v
    }

    private fun txt(t: String, size: Float, color: Int, bold: Boolean): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD)
        return v
    }

    private fun buildUi() {
        root = FrameLayout(this)
        root.setBackgroundColor(0xFF000000.toInt())

        sv = SurfaceView(this)
        root.addView(sv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))

        // audio / loading artwork
        art = FrameLayout(this)
        art.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF1B2252.toInt(), 0xFF0B0D14.toInt()))
        artImg = ImageView(this)
        artImg.scaleType = ImageView.ScaleType.CENTER_CROP
        artImg.alpha = 0.55f
        art.addView(artImg, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val note = ImageView(this)
        note.setImageResource(R.drawable.ic_music)
        note.setColorFilter(0x88FFFFFF.toInt())
        art.addView(note, FrameLayout.LayoutParams(dp(96), dp(96), Gravity.CENTER))
        root.addView(art, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        spin = ProgressBar(this)
        root.addView(spin, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.CENTER))

        // controls overlay
        ctl = FrameLayout(this)

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xCC000000.toInt(), 0x00000000))
        top.setPadding(dp(6), dp(8), dp(10), dp(24))
        top.addView(iconBtn(R.drawable.ic_back, 44, 11) { finish() })
        titleTv = txt("", 15f, 0xFFFFFFFF.toInt(), true)
        titleTv.maxLines = 1
        titleTv.ellipsize = android.text.TextUtils.TruncateAt.END
        val tl = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        tl.leftMargin = dp(4)
        top.addView(titleTv, tl)
        dlBtn = iconBtn(R.drawable.ic_download, 44, 11) { openDownload() }
        top.addView(dlBtn)
        pipBtn = iconBtn(R.drawable.ic_pip, 44, 11) { enterPip() }
        top.addView(pipBtn)
        speedTv = txt("1×", 14f, 0xFFFFFFFF.toInt(), true)
        speedTv.gravity = Gravity.CENTER
        speedTv.setOnClickListener {
            speedIdx = (speedIdx + 1) % speeds.size
            player?.setPlaybackSpeed(speeds[speedIdx])
            speedTv.text = speedLabel()
            scheduleHide()
        }
        top.addView(speedTv, LinearLayout.LayoutParams(dp(48), dp(44)))
        ctl.addView(top, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.HORIZONTAL
        mid.gravity = Gravity.CENTER
        mid.addView(iconBtn(R.drawable.ic_prev, 56, 16) { player?.seekToPrevious() })
        playBtn = iconBtn(R.drawable.ic_pause, 76, 20) { togglePlay() }
        playBtn.background = U.oval(0x66000000)
        val mp = LinearLayout.LayoutParams(dp(76), dp(76))
        mp.leftMargin = dp(18)
        mp.rightMargin = dp(18)
        playBtn.layoutParams = mp
        mid.addView(playBtn)
        mid.addView(iconBtn(R.drawable.ic_next, 56, 16) { player?.seekToNext() })
        ctl.addView(mid, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        val bot = LinearLayout(this)
        bot.orientation = LinearLayout.HORIZONTAL
        bot.gravity = Gravity.CENTER_VERTICAL
        bot.background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(0xCC000000.toInt(), 0x00000000))
        bot.setPadding(dp(14), dp(24), dp(6), dp(10))
        curTv = txt("0:00", 12f, 0xFFFFFFFF.toInt(), false)
        durTv = txt("0:00", 12f, 0xFFFFFFFF.toInt(), false)
        seek = SeekBar(this)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) curTv.text = tm(p.toLong())
            }

            override fun onStartTrackingTouch(s: SeekBar?) {
                dragging = true
                U.main.removeCallbacks(hideCtl)
            }

            override fun onStopTrackingTouch(s: SeekBar?) {
                dragging = false
                player?.seekTo((s?.progress ?: 0).toLong())
                scheduleHide()
            }
        })
        bot.addView(curTv)
        bot.addView(seek, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bot.addView(durTv)
        bot.addView(iconBtn(R.drawable.ic_full, 44, 11) { toggleOrientation() })
        ctl.addView(bot, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        root.addView(ctl, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // gesture hint
        hint = txt("", 18f, 0xFFFFFFFF.toInt(), true)
        hint.gravity = Gravity.CENTER
        hint.setPadding(dp(18), dp(10), dp(18), dp(10))
        hint.background = U.shape(0xAA000000.toInt(), dp(14).toFloat())
        hint.visibility = View.GONE
        root.addView(hint, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL or Gravity.TOP).apply { topMargin = dp(90) })

        // error box
        errBox = LinearLayout(this)
        errBox.orientation = LinearLayout.VERTICAL
        errBox.gravity = Gravity.CENTER
        errBox.setPadding(dp(28), dp(20), dp(28), dp(20))
        errBox.background = U.shape(0xE6121623.toInt(), dp(20).toFloat())
        errTv = txt("", 15f, 0xFFFFFFFF.toInt(), false)
        errTv.gravity = Gravity.CENTER
        errBtn = txt("Close", 15f, 0xFFFFFFFF.toInt(), true)
        errBtn.gravity = Gravity.CENTER
        errBtn.background = U.shape(C.ac, dp(14).toFloat())
        errBtn.setOnClickListener { onErrAction() }
        errBox.addView(errTv)
        val ebp = LinearLayout.LayoutParams(dp(180), dp(46))
        ebp.topMargin = dp(16)
        errBox.addView(errBtn, ebp)
        errBox.visibility = View.GONE
        val ep = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER)
        ep.leftMargin = dp(24)
        ep.rightMargin = dp(24)
        root.addView(errBox, ep)

        // gestures
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                volF = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()
                return true
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                showControls(!ctlOn)
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                val w = root.width
                if (e.x < w / 3f) seekBy(-10000L)
                else if (e.x > w * 2f / 3f) seekBy(10000L)
                else togglePlay()
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (e1 == null || root.height == 0) return false
                if (Math.abs(dy) < Math.abs(dx)) return false
                val delta = dy / root.height
                if (e1.x < root.width / 2f) {
                    val lp = window.attributes
                    var b = lp.screenBrightness
                    if (b < 0f) b = 0.5f
                    b = (b + delta * 1.2f).coerceIn(0.02f, 1f)
                    lp.screenBrightness = b
                    window.attributes = lp
                    flash("Brightness " + (b * 100).toInt() + "%")
                } else {
                    val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    volF = (volF + delta * max * 1.2f).coerceIn(0f, max.toFloat())
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, volF.toInt(), 0)
                    flash("Volume " + (volF * 100 / max).toInt() + "%")
                }
                return true
            }
        })
        root.setOnTouchListener { _, ev ->
            gd.onTouchEvent(ev)
            true
        }
        root.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> layoutSurface() }
    }

    private fun speedLabel(): String {
        val s = speeds[speedIdx]
        return (if (s == s.toInt().toFloat()) s.toInt().toString() else s.toString()) + "×"
    }

    private fun tm(ms: Long): String {
        val s = if (ms < 0L) 0L else ms / 1000
        val h = s / 3600
        val m = s % 3600 / 60
        val x = s % 60
        return if (h > 0) String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, x)
        else String.format(java.util.Locale.US, "%d:%02d", m, x)
    }

    private fun flash(t: String) {
        hint.text = t
        hint.visibility = View.VISIBLE
        U.main.removeCallbacks(hideHint)
        U.main.postDelayed(hideHint, 700)
    }

    @Suppress("DEPRECATION")
    private fun immersive() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) immersive()
    }

    private fun layoutSurface() {
        val cw = root.width
        val ch = root.height
        if (cw == 0 || ch == 0 || vw <= 0f || vh <= 0f) return
        val r = vw / vh
        var w = cw
        var h = (cw / r).toInt()
        if (h > ch) {
            h = ch
            w = (ch * r).toInt()
        }
        val lp = sv.layoutParams as FrameLayout.LayoutParams
        if (lp.width != w || lp.height != h) {
            lp.width = w
            lp.height = h
            lp.gravity = Gravity.CENTER
            sv.layoutParams = lp
        }
    }

    // --------------------------------------------------------------- controls
    private fun showControls(on: Boolean) {
        ctlOn = on
        if (on) {
            ctl.visibility = View.VISIBLE
            ctl.animate().alpha(1f).setDuration(160).start()
            scheduleHide()
        } else {
            ctl.animate().alpha(0f).setDuration(160).withEndAction { if (!ctlOn) ctl.visibility = View.GONE }.start()
        }
    }

    private fun scheduleHide() {
        U.main.removeCallbacks(hideCtl)
        val p = player
        if (p != null && p.isPlaying && !dragging) U.main.postDelayed(hideCtl, 3200)
    }

    private fun togglePlay() {
        val p = player ?: return
        if (p.playbackState == Player.STATE_ENDED) {
            p.seekTo(0L)
            p.play()
        } else if (p.isPlaying) p.pause() else p.play()
    }

    private fun seekBy(d: Long) {
        val p = player ?: return
        val dur = p.duration
        var t = p.currentPosition + d
        if (t < 0L) t = 0L
        if (dur > 0L && dur != MC.TIME_UNSET && t > dur) t = dur
        p.seekTo(t)
        flash(if (d < 0L) "−10s" else "+10s")
    }

    private fun toggleOrientation() {
        requestedOrientation = if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE)
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        rotated = true
    }

    private fun updateProgress() {
        val p = player ?: return
        if (!dragging) {
            val pos = p.currentPosition
            seek.progress = pos.toInt()
            curTv.text = tm(pos)
        }
        seek.secondaryProgress = p.bufferedPosition.toInt()
    }

    private fun applyItemUi() {
        val i = index.coerceIn(0, maxOf(0, titles.size - 1))
        titleTv.text = if (i < titles.size) titles[i] else ""
        val isA = if (i < kinds.size) kinds[i] == "a" else false
        isAudio = isA
        val th = if (i < thumbs.size) thumbs[i] else ""
        if (th.startsWith("http")) Img.load(th, artImg) else if (th.isNotEmpty()) Img.loadFile(th, artImg)
        art.visibility = if (isA || stream) View.VISIBLE else art.visibility
        dlBtn.visibility = if (stream) View.VISIBLE else View.GONE
        pipBtn.visibility = if (isA) View.GONE else View.VISIBLE
        speedTv.text = speedLabel()
    }

    // --------------------------------------------------------------- playback
    private fun startPlayer() {
        val p = ExoPlayer.Builder(this).build()
        player = p
        p.setAudioAttributes(
            AudioAttributes.Builder().setUsage(MC.USAGE_MEDIA).setContentType(MC.AUDIO_CONTENT_TYPE_MOVIE).build(), true
        )
        p.setHandleAudioBecomingNoisy(true)
        p.setVideoSurfaceView(sv)
        p.addListener(listener)
        if (stream) resolveStream() else loadLocal()
        U.main.post(tick)
    }

    private fun loadLocal() {
        val p = player ?: return
        val items = ArrayList<MediaItem>()
        for (u in uris) items.add(MediaItem.fromUri(Uri.parse(u)))
        applyItemUi()
        errBox.visibility = View.GONE
        p.setMediaItems(items, index, 0L)
        p.prepare()
        p.play()
    }

    private fun resolveStream() {
        spin.visibility = View.VISIBLE
        errBox.visibility = View.GONE
        applyItemUi()
        val my = ++token
        U.io.execute {
            try {
                val info = Engine.info(pageUrl, Engine.cookies(pageUrl))
                val pl = info.play(streamH) ?: throw Exception("No playable stream for this link. Download it instead.")
                U.main.post { if (my == token) playStream(pl, info) }
            } catch (e: Exception) {
                val m = e.message ?: "Could not load the stream"
                U.main.post { if (my == token) showMsg(m) }
            }
        }
    }

    private fun playStream(pl: Play, info: Info) {
        val p = player ?: return
        titles = arrayOf(info.title)
        titleTv.text = info.title
        p.setMediaSource(buildSource(pl))
        p.prepare()
        p.play()
    }

    private fun httpFactory(headers: String): DefaultHttpDataSource.Factory {
        val m = HashMap<String, String>()
        var ua: String? = null
        try {
            val j = JSONObject(headers)
            val ks = j.keys()
            while (ks.hasNext()) {
                val k = ks.next()
                val v = j.optString(k)
                if (k.equals("User-Agent", true)) ua = v
                else if (!k.equals("Accept-Encoding", true) && v.isNotEmpty()) m[k] = v
            }
        } catch (e: Exception) {
        }
        val f = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(20000)
        val u = ua
        if (u != null) f.setUserAgent(u)
        f.setDefaultRequestProperties(m)
        return f
    }

    private fun buildSource(pl: Play): MediaSource {
        val vf = httpFactory(pl.vh)
        val item = MediaItem.fromUri(Uri.parse(pl.v))
        if (pl.hls) return HlsMediaSource.Factory(vf).createMediaSource(item)
        val vs = ProgressiveMediaSource.Factory(vf).createMediaSource(item)
        val a = pl.a ?: return vs
        val asrc = ProgressiveMediaSource.Factory(httpFactory(pl.ah)).createMediaSource(MediaItem.fromUri(Uri.parse(a)))
        return MergingMediaSource(vs, asrc)
    }

    // ----------------------------------------------------------------- errors
    private fun showMsg(m: String) {
        spin.visibility = View.GONE
        errTv.text = m
        errBtn.text = if (stream) "Download instead" else "Open with…"
        errBox.visibility = View.VISIBLE
    }

    private fun onErrAction() {
        if (stream) {
            errBox.visibility = View.GONE
            openDownload()
        } else {
            val u = if (index < uris.size) uris[index] else return
            try {
                val i = Intent(Intent.ACTION_VIEW)
                i.setDataAndType(Uri.parse(u), if (isAudio) "audio/*" else "video/*")
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(i)
            } catch (e: Exception) {
                finish()
            }
        }
    }

    private fun openDownload() {
        if (pageUrl.isEmpty()) return
        var s = sheet
        if (s == null) {
            s = FormatSheet(this, root) { }
            sheet = s
        }
        s.show(pageUrl, if (titles.isNotEmpty()) titles[0] else "", if (thumbs.isNotEmpty()) thumbs[0] else "", 0L, "")
    }

    override fun onBackPressed() {
        val s = sheet
        if (s != null && s.showing) {
            s.dismiss()
            return
        }
        super.onBackPressed()
    }

    // -------------------------------------------------------------------- PiP
    private fun enterPip() {
        if (isAudio || Build.VERSION.SDK_INT < 26) return
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) return
        try {
            var r = if (vw > 0f && vh > 0f) vw / vh else 16f / 9f
            r = r.coerceIn(0.45f, 2.3f)
            val params = PictureInPictureParams.Builder().setAspectRatio(Rational((r * 1000).toInt(), 1000)).build()
            enterPictureInPictureMode(params)
        } catch (e: Exception) {
        }
    }

    override fun onUserLeaveHint() {
        val p = player
        if (p != null && p.isPlaying && !isAudio && Prefs.pip && vw > 0f) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        ctl.visibility = if (isInPictureInPictureMode) View.GONE else View.VISIBLE
        if (!isInPictureInPictureMode) showControls(true)
        root.post { layoutSurface() }
    }

    // -------------------------------------------------------------- lifecycle
    override fun onPause() {
        super.onPause()
        val p = player
        if (p != null && !isFinishing && !isInPictureInPictureMode && Prefs.bgplay && p.isPlaying) {
            try {
                val i = Intent(this, KeepService::class.java)
                i.putExtra("title", titleTv.text.toString())
                startForegroundService(i)
                userBg = true
            } catch (e: Exception) {
            }
        }
    }

    override fun onStop() {
        super.onStop()
        if (!isInPictureInPictureMode && !userBg) player?.pause()
    }

    override fun onStart() {
        super.onStart()
        if (userBg) {
            stopService(Intent(this, KeepService::class.java))
            userBg = false
        }
    }

    override fun onDestroy() {
        U.main.removeCallbacks(tick)
        U.main.removeCallbacks(hideCtl)
        token++
        if (userBg) stopService(Intent(this, KeepService::class.java))
        player?.release()
        player = null
        super.onDestroy()
    }
}
