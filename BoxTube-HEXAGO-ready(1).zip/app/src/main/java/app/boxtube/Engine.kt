package app.boxtube

import android.app.Application
import android.content.Context
import android.net.Uri
import android.webkit.CookieManager
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.TreeSet
import java.util.concurrent.Callable
import java.util.concurrent.ExecutionException
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.FutureTask

/** A directly playable stream (for the in-app player). */
class Play(val v: String, val vh: String, val a: String?, val ah: String, val hls: Boolean)

/** One video quality row in the download sheet. */
class VOpt(val h: Int, val size: Long, val merge: Boolean)

class Info(
    val url: String,
    val title: String,
    val who: String,
    val dur: Long,
    val thumb: String,
    val live: Boolean,
    val video: List<VOpt>,
    val audioSize: Long,
    val file: File?,
    val plays: Map<Int, Play>,
    val time: Long
) {
    fun play(h: Int): Play? {
        val exact = plays[h]
        if (exact != null) return exact
        val ks = plays.keys.filter { it > 0 }.sorted()
        if (ks.isEmpty()) return plays[0]
        val pick = ks.lastOrNull { it <= h } ?: ks.first()
        return plays[pick]
    }
}

object Engine {
    lateinit var app: Application

    /** true when the aria2c multi-connection downloader is available */
    @Volatile
    var aria = false

    @Volatile
    private var failed: String? = null
    private val pool = Executors.newCachedThreadPool()
    private var bootJob: Future<*>? = null
    private val cache = LinkedHashMap<String, Info>()
    private val flights = HashMap<String, FutureTask<Info>>()
    private val NO_COOKIE = arrayOf("youtube.com", "youtu.be", "google.com", "googlevideo.com", "ytimg.com")

    /** Starts python + yt-dlp + ffmpeg (+ aria2c) in the background as early as possible. */
    fun boot(a: Application) {
        app = a
        bootJob = pool.submit(Runnable {
            try {
                YoutubeDL.getInstance().init(a)
                FFmpeg.getInstance().init(a)
                aria = initAria(a)
            } catch (e: Throwable) {
                failed = e.message ?: e.javaClass.simpleName
            }
        })
    }

    private fun initAria(a: Application): Boolean {
        return try {
            val c = Class.forName("com.yausername.aria2c.Aria2c")
            val inst: Any? = try {
                c.getMethod("getInstance").invoke(null)
            } catch (e: NoSuchMethodException) {
                c.getField("INSTANCE").get(null)
            }
            c.getMethod("init", Context::class.java).invoke(inst, a)
            true
        } catch (e: Throwable) {
            false
        }
    }

    fun await() {
        try {
            bootJob?.get()
        } catch (e: Exception) {
            throw Exception("Engine failed to start")
        }
        val f = failed
        if (f != null) throw Exception("Engine failed to start: $f")
    }

    fun version(): String = try {
        await()
        YoutubeDL.getInstance().version(app) ?: "?"
    } catch (e: Exception) {
        "?"
    }

    fun update(): String = try {
        await()
        YoutubeDL.getInstance().updateYoutubeDL(app)?.toString() ?: "FAIL"
    } catch (e: Exception) {
        "FAIL"
    }

    fun kill(id: String) {
        try {
            YoutubeDL.getInstance().destroyProcessById(id)
        } catch (e: Exception) {
        }
    }

    // ---------------------------------------------------------------- cookies
    /** Exports the in-app browser login cookies so private/login-only videos work (not for YouTube/Google). */
    fun cookies(url: String): File? {
        return try {
            val host = Uri.parse(url).host ?: return null
            if (NO_COOKIE.any { host == it || host.endsWith(".$it") }) return null
            val raw = CookieManager.getInstance().getCookie(url) ?: return null
            if (raw.isBlank()) return null
            val parts = host.split(".")
            val root = if (parts.size >= 2) parts.takeLast(2).joinToString(".") else host
            val sb = StringBuilder("# Netscape HTTP Cookie File\n")
            for (kv in raw.split(";")) {
                val p = kv.trim()
                val i = p.indexOf('=')
                if (i <= 0) continue
                sb.append(".").append(root).append("\tTRUE\t/\tFALSE\t2147483647\t")
                    .append(p.substring(0, i)).append("\t").append(p.substring(i + 1)).append("\n")
            }
            val f = File(app.cacheDir, "cookies/" + U.md5(root) + ".txt")
            f.parentFile?.mkdirs()
            f.writeText(sb.toString())
            f
        } catch (e: Exception) {
            null
        }
    }

    // ------------------------------------------------------------------- info
    fun info(url: String, cookie: File? = null): Info {
        synchronized(cache) {
            val hit = cache[url]
            if (hit != null && System.currentTimeMillis() - hit.time < 20 * 60 * 1000L) return hit
        }
        val pr = synchronized(flights) {
            val ex = flights[url]
            if (ex != null) {
                Pair(ex, false)
            } else {
                val t = FutureTask<Info>(Callable<Info> { fetch(url, cookie) })
                flights[url] = t
                Pair(t, true)
            }
        }
        val task = pr.first
        if (pr.second) pool.execute(task)
        try {
            return task.get()
        } catch (e: ExecutionException) {
            val c = e.cause
            throw (if (c is Exception) c else Exception(e.message))
        } finally {
            if (pr.second) synchronized(flights) { flights.remove(url) }
        }
    }

    /** Warm the cache so the download sheet opens instantly. */
    fun prefetch(url: String) {
        pool.execute {
            try {
                info(url, cookies(url))
            } catch (e: Exception) {
            }
        }
    }

    private fun str(x: JSONObject, k: String): String = if (x.isNull(k)) "" else x.optString(k, "")

    private fun res(x: JSONObject): Int {
        val w = x.optInt("width", 0)
        val h = x.optInt("height", 0)
        return if (w > 0 && h > 0) minOf(w, h) else h
    }

    private fun isHls(x: JSONObject): Boolean = str(x, "protocol").contains("m3u8")

    private fun isHttp(x: JSONObject): Boolean {
        val p = str(x, "protocol")
        return str(x, "url").isNotEmpty() && (p == "https" || p == "http")
    }

    private fun hasAudio(x: JSONObject): Boolean {
        val ac = str(x, "acodec")
        return ac.isNotEmpty() && ac != "none"
    }

    private fun fsize(x: JSONObject, dur: Long): Long {
        var s = x.optLong("filesize", 0L)
        if (s <= 0L) s = x.optLong("filesize_approx", 0L)
        if (s <= 0L && dur > 0L) {
            val tbr = x.optDouble("tbr", 0.0)
            if (tbr > 0.0) s = (tbr * 1000.0 / 8.0 * dur).toLong()
        }
        return s
    }

    private fun hdr(x: JSONObject): String = (x.optJSONObject("http_headers") ?: JSONObject()).toString()

    private fun fetch(url: String, cookie: File?): Info {
        await()
        val r = YoutubeDLRequest(url)
        r.addOption("-J")
        r.addOption("--no-playlist")
        r.addOption("--no-warnings")
        r.addOption("--socket-timeout", "20")
        r.addOption("--extractor-retries", "2")
        if (cookie != null) r.addOption("--cookies", cookie.absolutePath)
        val out = YoutubeDL.getInstance().execute(r).out
        val j = JSONObject(out)
        if (j.optString("_type") == "playlist") throw Exception("This is a playlist link. Open one video from it.")

        var dur = j.optDouble("duration", 0.0)
        if (dur.isNaN()) dur = 0.0
        val d = dur.toLong()
        val fm = j.optJSONArray("formats") ?: JSONArray()

        val hs = TreeSet<Int>()
        var au = 0L
        for (i in 0 until fm.length()) {
            val x = fm.optJSONObject(i) ?: continue
            if (str(x, "ext") == "mhtml") continue
            if (str(x, "vcodec") == "none") {
                if (hasAudio(x)) au = maxOf(au, fsize(x, d))
            } else {
                val h = res(x)
                if (h > 0) hs.add(h)
            }
        }
        var list: List<Int> = hs.toList()
        if (list.size > 6) list = list.filter { it > 240 }
        if (list.size > 6) list = list.takeLast(6)

        val vopts = ArrayList<VOpt>()
        for (h in list) {
            var best: JSONObject? = null
            var bs = -1
            for (i in 0 until fm.length()) {
                val x = fm.optJSONObject(i) ?: continue
                if (str(x, "vcodec") == "none" || res(x) != h || str(x, "ext") == "mhtml") continue
                val sc = (if (str(x, "ext") == "mp4") 2 else 0) + (if (str(x, "vcodec").startsWith("avc")) 1 else 0)
                if (sc > bs) {
                    bs = sc
                    best = x
                }
            }
            val b = best
            val comb = b != null && hasAudio(b)
            val size = if (b != null) fsize(b, d) + (if (comb) 0L else au) else 0L
            vopts.add(VOpt(h, size, !comb))
        }

        var file: File? = null
        try {
            val f = File(app.cacheDir, "info/" + U.md5(url) + ".json")
            f.parentFile?.mkdirs()
            f.writeText(out)
            file = f
        } catch (e: Exception) {
        }

        val who = if (str(j, "uploader").isNotEmpty()) str(j, "uploader") else str(j, "channel")
        val title = if (str(j, "title").isNotEmpty()) str(j, "title") else "Video"
        val inf = Info(
            url, title, who, d, str(j, "thumbnail"), j.optBoolean("is_live", false),
            vopts, au, file, buildPlays(fm, list), System.currentTimeMillis()
        )
        synchronized(cache) {
            cache[url] = inf
            if (cache.size > 12) cache.remove(cache.keys.first())
        }
        return inf
    }

    private fun buildPlays(fm: JSONArray, hs: List<Int>): Map<Int, Play> {
        val out = LinkedHashMap<Int, Play>()
        var ba: JSONObject? = null
        var bas = -1.0
        for (i in 0 until fm.length()) {
            val x = fm.optJSONObject(i) ?: continue
            if (str(x, "vcodec") == "none" && hasAudio(x) && isHttp(x)) {
                var abr = x.optDouble("abr", 0.0)
                if (abr.isNaN()) abr = 0.0
                val sc = (if (str(x, "ext") == "m4a") 1000.0 else 0.0) + abr
                if (sc > bas) {
                    bas = sc
                    ba = x
                }
            }
        }
        val a = ba
        if (a != null) out[0] = Play(str(a, "url"), hdr(a), null, "", false)
        for (h in hs) {
            var best: JSONObject? = null
            var bs = -1
            for (i in 0 until fm.length()) {
                val x = fm.optJSONObject(i) ?: continue
                if (str(x, "vcodec") == "none" || res(x) != h) continue
                if (!(isHttp(x) || (isHls(x) && str(x, "url").isNotEmpty()))) continue
                val sc = (if (hasAudio(x)) 4 else 0) + (if (str(x, "ext") == "mp4") 2 else 0) +
                    (if (str(x, "vcodec").startsWith("avc")) 1 else 0)
                if (sc > bs) {
                    bs = sc
                    best = x
                }
            }
            val b = best ?: continue
            val hls = isHls(b)
            out[h] = if (hasAudio(b) || a == null || hls) {
                Play(str(b, "url"), hdr(b), null, "", hls)
            } else {
                Play(str(b, "url"), hdr(b), str(a, "url"), hdr(a), false)
            }
        }
        return out
    }

    // ----------------------------------------------------------------- search
    /** YouTube search used by the Home feed. Returns [{i,t,c,d,v}]. */
    fun search(q: String, n: Int): JSONArray {
        await()
        val r = YoutubeDLRequest("ytsearch" + n + ":" + q)
        r.addOption("-J")
        r.addOption("--flat-playlist")
        r.addOption("--no-warnings")
        r.addOption("--socket-timeout", "15")
        val j = JSONObject(YoutubeDL.getInstance().execute(r).out)
        val en = j.optJSONArray("entries") ?: JSONArray()
        val out = JSONArray()
        for (i in 0 until en.length()) {
            val e = en.optJSONObject(i) ?: continue
            val id = str(e, "id")
            if (id.length != 11) continue
            val who = if (str(e, "channel").isNotEmpty()) str(e, "channel") else str(e, "uploader")
            var dd = e.optDouble("duration", 0.0)
            if (dd.isNaN()) dd = 0.0
            val o = JSONObject()
            o.put("i", id)
            o.put("t", str(e, "title"))
            o.put("c", who)
            o.put("d", dd.toLong())
            o.put("v", e.optLong("view_count", 0L))
            out.put(o)
        }
        return out
    }

    // --------------------------------------------------------------- download
    fun request(t: Task, dir: File, aria: Boolean, useInfo: Boolean): YoutubeDLRequest {
        val r = YoutubeDLRequest(t.url)
        val inf = t.infoFile
        if (useInfo && inf != null && File(inf).exists()) r.addOption("--load-info-json", inf)
        r.addOption("--no-playlist")
        r.addOption("--no-mtime")
        r.addOption("--no-warnings")
        r.addOption("--retries", "6")
        r.addOption("--fragment-retries", "6")
        r.addOption("--socket-timeout", "20")
        r.addOption("-o", dir.path + "/%(title).80s.%(ext)s")
        if (t.kind == "a") {
            r.addOption("-x")
            r.addOption("--audio-format", t.res)
            if (t.res == "mp3") r.addOption("--audio-quality", "0")
            r.addOption("--embed-metadata")
        } else {
            r.addOption("-S", "res:" + t.res + ",ext")
            r.addOption("--merge-output-format", "mp4")
        }
        if (Prefs.turbo) {
            r.addOption("-N", "8")
            if (aria) {
                r.addOption("--downloader", "libaria2c.so")
                r.addOption("--external-downloader-args", "aria2c:--summary-interval=1")
            }
        }
        val ck = t.cookie
        if (ck != null && File(ck).exists()) r.addOption("--cookies", ck)
        return r
    }
}
