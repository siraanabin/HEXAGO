package app.boxtube

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.HapticFeedbackConstants
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

@Suppress("DEPRECATION")
class MainActivity : Activity(), DlListener, BrowserView.Cb {
    private lateinit var root: FrameLayout
    private lateinit var wv: WebView
    private lateinit var sheet: FormatSheet
    private var browser: BrowserView? = null
    private var pendingLink: String? = null
    private val h = U.main

    private fun js(s: String) {
        h.post { wv.evaluateJavascript(s, null) }
    }

    private fun q(s: String?): String = JSONObject.quote(s ?: "")

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        root = FrameLayout(this)
        root.setBackgroundColor(C.bg)

        wv = WebView(this)
        wv.setBackgroundColor(C.bg)
        wv.overScrollMode = android.view.View.OVER_SCROLL_NEVER
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.textZoom = 100
        s.setSupportZoom(false)
        wv.addJavascriptInterface(Bridge(), "Android")
        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val u = r.url
                if (u.host != "app.local") return null
                return serve(u.path ?: "/")
            }

            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url
                if (u.host == "app.local") return false
                openBrowser(u.toString())
                return true
            }
        }
        root.addView(wv, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        sheet = FormatSheet(this, root) {
            browser?.close()
            js("NB.go('dl')")
        }
        pendingLink = linkOf(intent)
        wv.loadUrl("https://app.local/index.html")

        // warm up the browser WebView a moment after the first frame so "open site" is instant
        h.postDelayed({ if (browser == null && !isFinishing) ensureBrowser() }, 1800)
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        setIntent(i)
        val l = linkOf(i)
        if (l != null) js("NB.link(${q(l)})")
    }

    private fun linkOf(i: Intent?): String? {
        val t = i?.getStringExtra(Intent.EXTRA_TEXT) ?: return null
        return Regex("https?://\\S+").find(t)?.value
    }

    override fun onStart() {
        super.onStart()
        Downloads.listener = this
        pushAll()
    }

    override fun onStop() {
        Downloads.listener = null
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        wv.onResume()
        browser?.hostResume()
    }

    override fun onPause() {
        browser?.hostPause()
        wv.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        Downloads.listener = null
        super.onDestroy()
    }

    override fun onWindowFocusChanged(f: Boolean) {
        super.onWindowFocusChanged(f)
        if (f && ::wv.isInitialized) clipPush()
    }

    // ---------------------------------------------------------------- serving
    private fun serve(p: String): WebResourceResponse {
        try {
            if (p == "/" || p == "/index.html") return WebResourceResponse("text/html", "utf-8", assets.open("index.html"))
            if (p.startsWith("/thumb/")) {
                val n = p.removePrefix("/thumb/")
                if (Regex("[A-Za-z0-9_-]+\\.jpg").matches(n)) {
                    val f = File(Thumbs.dir, n)
                    if (f.exists()) {
                        val r = WebResourceResponse("image/jpeg", null, FileInputStream(f))
                        r.responseHeaders = mapOf("Cache-Control" to "max-age=86400")
                        return r
                    }
                }
            }
        } catch (e: Exception) {
        }
        return WebResourceResponse("text/plain", "utf-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0)))
    }

    // ----------------------------------------------------------------- state
    private fun pushAll() {
        js("window.NB&&NB.tasks(${Downloads.tasksJson()})")
        js("window.NB&&NB.lib(${Downloads.libJson()})")
    }

    private fun pushInit() {
        val o = JSONObject()
        o.put("ver", BuildConfig.VERSION_NAME)
        o.put("set", Prefs.json())
        o.put("tasks", Downloads.tasksJson())
        o.put("lib", Downloads.libJson())
        js("NB.init($o)")
        val l = pendingLink
        if (l != null) {
            js("NB.link(${q(l)})")
            pendingLink = null
        }
        clipPush()
        U.io.execute {
            val v = Engine.version()
            js("NB.eng(${q(v)})")
        }
        h.postDelayed({ U.io.execute { checkApp() } }, 3500)
    }

    private fun clipPush() {
        try {
            val c = (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).primaryClip
            val t = if (c != null && c.itemCount > 0) c.getItemAt(0).coerceToText(this).toString().trim() else ""
            js("window.NB&&NB.clip(${q(t)})")
            if (t.startsWith("http") && BrowserView.isVideoUrl(t)) Engine.prefetch(t)
        } catch (e: Exception) {
        }
    }

    // ---------------------------------------------------------------- browser
    private fun ensureBrowser(): BrowserView {
        var b = browser
        if (b == null) {
            b = BrowserView(this, this)
            browser = b
            root.addView(b, 1, FrameLayout.LayoutParams(-1, -1))
        }
        return b
    }

    private fun openBrowser(u: String) {
        ensureBrowser().open(u)
    }

    override fun onClose() {
        browser?.close()
    }

    override fun onAnalyze(url: String) {
        sheet.show(url, "", "", 0L, "")
    }

    override fun onToast(m: String) {
        Snack.show(root, m)
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (sheet.showing) {
            sheet.dismiss()
            return
        }
        val b = browser
        if (b != null && b.isOpen) {
            if (!b.back()) b.close()
            return
        }
        wv.evaluateJavascript("NB.back()") { if (it != "true") finish() }
    }

    // --------------------------------------------------------- DlListener
    override fun onTasks(a: JSONArray) {
        js("NB.tasks($a)")
    }

    override fun onLib(a: JSONArray) {
        js("NB.lib($a)")
    }

    override fun onDone(o: JSONObject) {
        js("NB.done($o)")
    }

    // ------------------------------------------------------------ app update
    private fun checkApp() {
        try {
            val c = URL("https://api.github.com/repos/${BuildConfig.REPO}/releases/latest").openConnection() as HttpURLConnection
            c.setRequestProperty("Accept", "application/vnd.github+json")
            c.connectTimeout = 10000
            c.readTimeout = 10000
            val j = JSONObject(c.inputStream.bufferedReader().readText())
            val a = j.getJSONArray("assets")
            val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64-v8a"
            var apk = ""
            var any = ""
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val nm = o.getString("name")
                if (!nm.endsWith(".apk")) continue
                any = o.getString("browser_download_url")
                if (nm.contains(abi)) apk = any
            }
            if (apk.isEmpty()) apk = any
            val tag = j.getString("tag_name")
            val n = tag.substringAfterLast('.').toIntOrNull() ?: 0
            val o = JSONObject().put("tag", tag).put("new", n > BuildConfig.VERSION_CODE && apk.isNotEmpty()).put("url", apk)
            js("NB.app($o)")
        } catch (e: Exception) {
            js("NB.app(null)")
        }
    }

    // ----------------------------------------------------------------- bridge
    inner class Bridge {
        @JavascriptInterface
        fun ready() {
            h.post { pushInit() }
        }

        @JavascriptInterface
        fun hap() {
            h.post { wv.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY) }
        }

        @JavascriptInterface
        fun clip() {
            h.post { clipPush() }
        }

        @JavascriptInterface
        fun analyze(u: String, title: String, thumb: String, dur: Int, who: String) {
            h.post { sheet.show(u, title, thumb, dur.toLong(), who) }
        }

        @JavascriptInterface
        fun preview(u: String, title: String, thumb: String) {
            h.post {
                val i = Intent(this@MainActivity, PlayerActivity::class.java)
                i.putExtra("page", u)
                i.putExtra("h", 720)
                i.putExtra("title", title)
                i.putExtra("thumb", thumb)
                startActivity(i)
            }
        }

        @JavascriptInterface
        fun prefetch(u: String) {
            Engine.prefetch(u)
        }

        @JavascriptInterface
        fun browse(u: String) {
            h.post { openBrowser(u) }
        }

        @JavascriptInterface
        fun feed(tag: String, query: String) {
            U.io.execute {
                try {
                    val arr = Engine.search(query, 24)
                    js("NB.feed(${q(tag)},$arr)")
                } catch (e: Exception) {
                    js("NB.feedErr(${q(tag)},${q(e.message?.take(90))})")
                }
            }
        }

        @JavascriptInterface
        fun suggest(s: String) {
            U.io.execute {
                try {
                    val c = URL("https://suggestqueries.google.com/complete/search?client=firefox&ds=yt&q=" + URLEncoder.encode(s, "UTF-8")).openConnection() as HttpURLConnection
                    c.connectTimeout = 4000
                    c.readTimeout = 4000
                    val arr = JSONArray(c.inputStream.bufferedReader().readText()).getJSONArray(1)
                    js("NB.sug(${q(s)},$arr)")
                } catch (e: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun pause(id: String) {
            U.io.execute { Downloads.pause(id) }
        }

        @JavascriptInterface
        fun resume(id: String) {
            U.io.execute { Downloads.resume(id) }
        }

        @JavascriptInterface
        fun cancel(id: String) {
            U.io.execute { Downloads.cancel(id) }
        }

        @JavascriptInterface
        fun retry(id: String) {
            U.io.execute { Downloads.retry(id) }
        }

        @JavascriptInterface
        fun pauseAll() {
            U.io.execute { Downloads.pauseAll() }
        }

        @JavascriptInterface
        fun resumeAll() {
            U.io.execute { Downloads.resumeAll() }
        }

        @JavascriptInterface
        fun play(id: String, filter: String) {
            h.post {
                val list = Downloads.libSnapshot().filter {
                    filter == "All" || (filter == "Video" && it.kind == "v") || (filter == "Audio" && it.kind == "a")
                }
                val idx = list.indexOfFirst { it.id == id }
                if (idx >= 0) startActivity(Downloads.playIntent(this@MainActivity, list, idx))
            }
        }

        @JavascriptInterface
        fun share(id: String) {
            h.post {
                val x = Downloads.findItem(id)
                if (x != null) {
                    try {
                        val i = Intent(Intent.ACTION_SEND)
                        i.type = x.mime
                        i.putExtra(Intent.EXTRA_STREAM, Uri.parse(x.uri))
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        startActivity(Intent.createChooser(i, "Share"))
                    } catch (e: Exception) {
                        Snack.show(root, "Can't share this file")
                    }
                }
            }
        }

        @JavascriptInterface
        fun openWith(id: String) {
            h.post {
                val x = Downloads.findItem(id)
                if (x != null) {
                    try {
                        val i = Intent(Intent.ACTION_VIEW)
                        i.setDataAndType(Uri.parse(x.uri), x.mime)
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        startActivity(i)
                    } catch (e: Exception) {
                        Snack.show(root, "No app can open this file")
                    }
                }
            }
        }

        @JavascriptInterface
        fun del(id: String) {
            h.post {
                AlertDialog.Builder(this@MainActivity).setMessage("Delete this file from your phone?")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Delete") { _, _ ->
                        U.io.execute {
                            Downloads.delete(id)
                            js("NB.lib(${Downloads.libJson()})")
                        }
                    }.show()
            }
        }

        @JavascriptInterface
        fun pref(k: String, v: String) {
            val value: Any = if (k == "par") (v.toIntOrNull() ?: 2) else (v == "1" || v == "true")
            Prefs.put(k, value)
            if (k == "par" || k == "wifi" || k == "turbo") U.io.execute { Downloads.schedule() }
        }

        @JavascriptInterface
        fun checkApp() {
            U.io.execute { this@MainActivity.checkApp() }
        }

        @JavascriptInterface
        fun installApp(u: String) {
            U.io.execute {
                try {
                    val f = File(cacheDir, "update.apk")
                    URL(u).openStream().use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    h.post {
                        if (!packageManager.canRequestPackageInstalls()) {
                            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
                            js("NB.toast('Allow installs for BoxTube, then tap Install again')")
                        } else {
                            val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fp", f)
                            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                        }
                    }
                } catch (e: Exception) {
                    js("NB.toast('Update failed')")
                }
            }
        }

        @JavascriptInterface
        fun updEngine() {
            U.io.execute {
                val s = Engine.update()
                js("NB.engUpd(${q(s)})")
                js("NB.eng(${q(Engine.version())})")
            }
        }

        @JavascriptInterface
        fun exit() {
            h.post { finish() }
        }
    }
}
