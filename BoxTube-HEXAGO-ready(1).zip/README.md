# BoxTube 2.0 (Android)

Fast video & music downloader with an in-app browser and a built-in player.

## What's inside
- **Home**: one search bar for videos *and* links, site shortcuts (YouTube, Facebook, Instagram, TikTok, X, Vimeo …), category chips, a cached video feed that opens instantly.
- **Download sheet**: native bottom sheet with every quality (4K / 2K / 1080p / 720p …) and MP3 / M4A. Opens instantly with the title and thumbnail, and the link is pre-read in the background (clipboard link, browser page) so the formats are often ready before you tap.
- **In-app browser** with a floating download button that pulses when a video is found (YouTube, Facebook, Instagram, TikTok, X, Vimeo, Dailymotion … and any page with a playable video / media link). Login cookies from the browser are used for Facebook / Instagram / X style sites. Basic ad & tracker blocking (best effort).
- **Built-in player** (Media3 ExoPlayer): local files with playlist, streaming preview before download, double-tap to seek, swipe for brightness / volume, speed, picture-in-picture, optional background audio.
- **Download engine**: yt-dlp + FFmpeg + **aria2c Turbo** (multi-connection), resume after pause / app restart, parallel downloads, Wi-Fi only, foreground service + notifications so downloads keep running in the background.
- **Library** = everything in `Download/BoxTube` (real thumbnails, search, share, delete, open with).

## APK size
Python, yt-dlp and FFmpeg are bundled, so the app cannot be as tiny as apps that only call a server. The build now creates **one APK per CPU type** instead of one huge universal APK:

| File | Use |
|------|-----|
| `BoxTube-64bit-arm64-v8a.apk` | almost every phone (≈ half of the old size) |
| `BoxTube-32bit-armeabi-v7a.apk` | very old 32-bit phones only |

## GitHub Actions auto-build
- Push or upload project files to `main` (or `master`); Actions builds signed release APKs and publishes them in GitHub Releases (`v2.0.RUN_NUMBER`).

## One-time signing setup (required)
The signing key is intentionally not committed. Add these four values under **Settings → Secrets and variables → Actions → New repository secret**:

- `KEYSTORE_BASE64`: Base64 encoding of the original `boxtube.p12` file
- `KEYSTORE_PASSWORD`: `boxtube`
- `KEY_ALIAS`: `boxtube`
- `KEY_PASSWORD`: `boxtube`

(Linux/macOS: `base64 -w 0 boxtube.p12`; macOS may use `base64 boxtube.p12 | tr -d '\n'`.) Keep using the exact same key for every release, otherwise installed apps will refuse updates.

## In-app updates
- Settings → Updates → App checks the latest GitHub Release and installs the APK that matches your phone's CPU.
- Settings → Updates → Download engine updates yt-dlp independently (do this first if a site stops working).

Keep this repository **Public** so the app can read GitHub Releases without authentication.

## Notes
- Streaming preview depends on what the site allows; if it fails the player offers "Download instead".
- Ad blocking in the browser is best effort; sites change their ads often.
- The yt-dlp Android library is GPL-3.0; follow its license terms when distributing the app.
