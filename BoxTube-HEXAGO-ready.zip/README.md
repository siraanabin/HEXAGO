# BoxTube (Android)

## GitHub Actions auto-build
- Push or upload project files to `main` (or `master`) and GitHub Actions builds a signed release APK.
- The APK is uploaded as a workflow artifact and published in GitHub Releases as `BoxTube.apk`.
- Every successful run uses an increasing version code and version name (`1.0.RUN_NUMBER`).

## One-time signing setup (required)
The signing key is intentionally not committed to this public repository. Add these four values under **Settings → Secrets and variables → Actions → New repository secret**:

- `KEYSTORE_BASE64`: Base64 encoding of the original `boxtube.p12` file
- `KEYSTORE_PASSWORD`: `boxtube`
- `KEY_ALIAS`: `boxtube`
- `KEY_PASSWORD`: `boxtube`

On a computer with the original ZIP extracted, generate the base64 value from `boxtube.p12` (Linux/macOS: `base64 -w 0 boxtube.p12`; macOS may use `base64 boxtube.p12 | tr -d '\n'`). Keep the `.p12` file private and do not commit it.

**Important:** keep using the exact same signing key for every release. Replacing it prevents existing installations from accepting in-app updates.

## In-app updates
- Settings → Updates → App checks the latest GitHub Release and offers the APK.
- Settings → Updates → Download engine updates yt-dlp independently.

Keep this repository **Public** so the app can read GitHub Releases without authentication.

The yt-dlp Android library is GPL-3.0; follow its license terms when distributing the app.
