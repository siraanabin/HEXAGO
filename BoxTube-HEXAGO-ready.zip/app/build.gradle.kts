plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
val vc = (findProperty("versionCode") as String?)?.toInt() ?: 1
val vn = (findProperty("versionName") as String?) ?: "1.0.0"
val repo = (findProperty("repo") as String?) ?: "siraanabin/HEXAGO"
android {
    namespace = "app.boxtube"
    compileSdk = 34
    defaultConfig {
        applicationId = "app.boxtube"; minSdk = 29; targetSdk = 34
        versionCode = vc; versionName = vn
        buildConfigField("String", "REPO", "\\"$repo\\"")
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }
    buildFeatures { buildConfig = true }
    signingConfigs {
        create("release") {
            storeFile = rootProject.file("boxtube.p12")
            storeType = "pkcs12"
            storePassword = System.getenv("KEYSTORE_PASSWORD") ?: ""
            keyAlias = System.getenv("KEY_ALIAS") ?: "boxtube"
            keyPassword = System.getenv("KEY_PASSWORD") ?: ""
        }
    }
    buildTypes { release { signingConfig = signingConfigs.getByName("release"); isMinifyEnabled = false } }
    packaging { jniLibs { useLegacyPackaging = true } }
    lint { checkReleaseBuilds = false; abortOnError = false }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    val y = "0.18.1"
    implementation("io.github.junkfood02.youtubedl-android:library:$y")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:$y")
    implementation("androidx.core:core-ktx:1.13.1")
}
