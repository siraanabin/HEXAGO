package app.boxtube

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.view.Gravity
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import androidx.core.content.FileProvider
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.Future

@Suppress("DEPRECATION")
class MainActivity : Activity() {
    private lateinit var wv: WebView
    private lateinit var boot: Future<*>
    private var br: WebView? = null
    private val pool = Executors.newFixedThreadPool(4)
    private val h = Handler(Looper.getMainLooper())
    private val base by lazy { getExternalFilesDir(null) ?: filesDir }

    private fun js(s: String) { h.post { wv.evaluateJavascript(s, null) } }
    private fun q(s: String?): String = JSONObject.quote(s ?: "")

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        File(base, "dl").deleteRecursively()
        boot = pool.submit(Runnable { YoutubeDL.getInstance().init(application); FFmpeg.getInstance().init(application) })
        wv = WebView(this)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.addJavascriptInterface(Bridge(), "Android")
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, u: String?) { share(intent) }
        }
        setContentView(wv)
        wv.loadUrl("file:///android_asset/index.html")
    }

    private fun share(i: Intent?) {
        val t = i?.getStringExtra(Intent.EXTRA_TEXT) ?: return
        Regex("https?://\\S+").find(t)?.let { js("NB.link(${q(it.value)})") }
    }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); setIntent(i); share(i) }

    private fun clipPush() {
        val c = (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).primaryClip
        val t = if (c != null && c.itemCount > 0) c.getItemAt(0).coerceToText(this).toString() else ""
        js("window.NB&&NB.clip(${q(t.trim())})")
    }
    override fun onWindowFocusChanged(f: Boolean) { super.onWindowFocusChanged(f); if (f && ::wv.isInitialized) clipPush() }

    private fun keep(f: File): JSONObject {
        val m = mapOf("mp3" to "audio/mpeg", "m4a" to "audio/mp4", "mp4" to "video/mp4", "webm" to "video/webm", "mkv" to "video/x-matroska", "opus" to "audio/ogg")[f.extension.lowercase()] ?: "application/octet-stream"
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
            put(MediaStore.MediaColumns.MIME_TYPE, m)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/BoxTube")
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)!!
        contentResolver.openOutputStream(uri)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        val n = f.length()
        f.parentFile?.deleteRecursively()
        return JSONObject().put("u", uri.toString()).put("m", m).put("s", n)
    }

    private fun openBr(u: String) {
        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.webViewClient = WebViewClient()
        w.loadUrl(u)
        val b = Button(this)
        b.text = "\u2B07  Download"
        b.setTextColor(-1)
        b.setBackgroundColor(0xFF3F5BFF.toInt())
        b.setOnClickListener { val cu = w.url ?: u; closeBr(); js("NB.link(${q(cu)})") }
        val root = FrameLayout(this)
        root.addView(w)
        root.addView(b, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, 40, 60) })
        setContentView(root)
        br = w
    }
    private fun closeBr() { br?.destroy(); br = null; setContentView(wv) }
    override fun onBackPressed() {
        val w = br
        if (w != null) { if (w.canGoBack()) w.goBack() else closeBr(); return }
        wv.evaluateJavascript("NB.back()") { if (it != "true") finish() }
    }

    inner class Bridge {
        @JavascriptInterface fun ver(): String = BuildConfig.VERSION_NAME
        @JavascriptInterface fun clip() { h.post { clipPush() } }
        @JavascriptInterface fun browse(u: String) { h.post { openBr(u) } }

        @JavascriptInterface fun info(u: String) {
            pool.execute {
                try {
                    boot.get()
                    val r = YoutubeDL.getInstance().execute(YoutubeDLRequest(u).apply { addOption("-J"); addOption("--no-playlist"); addOption("--no-warnings") })
                    val j = JSONObject(r.out)
                    val f = j.optJSONArray("formats") ?: JSONArray()
                    fun sz(x: JSONObject) = x.optLong("filesize", x.optLong("filesize_approx", 0L))
                    var au = 0L
                    var hm = 0
                    for (i in 0 until f.length()) {
                        val x = f.getJSONObject(i)
                        if (x.optString("vcodec") == "none") au = maxOf(au, sz(x)) else hm = maxOf(hm, x.optInt("height"))
                    }
                    fun vs(hh: Int): Long {
                        var s = 0L; var bh = 0
                        for (i in 0 until f.length()) {
                            val x = f.getJSONObject(i); val xh = x.optInt("height")
                            if (x.optString("vcodec") != "none" && xh <= hh && xh >= bh && sz(x) > 0) { bh = xh; s = sz(x) }
                        }
                        return s + au
                    }
                    val v = JSONArray()
                    for (hh in (listOf(360, 720, 1080, 1440, 2160).filter { it <= hm } + hm).distinct().filter { it > 0 }) v.put(JSONArray().put(hh).put(vs(hh)))
                    val o = JSONObject().put("t", j.optString("title")).put("c", j.optString("uploader")).put("d", j.optLong("duration")).put("i", j.optString("thumbnail")).put("v", v).put("a", au)
                    js("NB.info($o)")
                } catch (e: Exception) { js("NB.err(${q(e.message?.take(80))})") }
            }
        }

        @JavascriptInterface fun dl(id: String, u: String, k: String, res: String, turbo: Boolean) {
            pool.execute {
                try {
                    boot.get()
                    val dir = File(base, "dl/$id").apply { mkdirs() }
                    val r = YoutubeDLRequest(u)
                    r.addOption("--no-playlist"); r.addOption("--no-mtime")
                    r.addOption("-o", "${dir.path}/%(title).80s.%(ext)s")
                    if (k == "a") {
                        r.addOption("-x"); r.addOption("--audio-format", res)
                        if (res == "mp3") r.addOption("--audio-quality", "0")
                    } else { r.addOption("-S", "res:$res,ext"); r.addOption("--merge-output-format", "mp4") }
                    if (turbo) r.addOption("-N", "8")
                    YoutubeDL.getInstance().execute(r, id) { p, e, l -> js("NB.prog('$id',$p,$e,${q(l)})") }
                    val f = dir.listFiles()?.filter { !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }?.maxByOrNull { it.length() } ?: throw Exception("No file")
                    js("NB.done('$id',${keep(f)})")
                } catch (e: Exception) { js("NB.err2('$id',${q(e.message?.take(80))})") }
            }
        }

        @JavascriptInterface fun cancel(id: String) { pool.execute { try { YoutubeDL.getInstance().destroyProcessById(id) } catch (e: Exception) { } } }

        @JavascriptInterface fun open(u: String, m: String) {
            h.post {
                try { startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(u), m).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
                catch (e: Exception) { js("NB.toast('No app can open this file')") }
            }
        }

        @JavascriptInterface fun del(u: String, i: Int) {
            h.post {
                AlertDialog.Builder(this@MainActivity).setMessage("Delete this file?").setNegativeButton("Cancel", null)
                    .setPositiveButton("Delete") { _, _ -> try { contentResolver.delete(Uri.parse(u), null, null) } catch (e: Exception) { }; js("NB.deleted($i)") }.show()
            }
        }

        @JavascriptInterface fun engine() {
            pool.execute {
                try { boot.get(); js("NB.eng(${q(YoutubeDL.getInstance().version(this@MainActivity))})") } catch (e: Exception) { js("NB.eng('?')") }
            }
        }

        @JavascriptInterface fun updEngine() {
            pool.execute {
                try {
                    boot.get()
                    val s = YoutubeDL.getInstance().updateYoutubeDL(this@MainActivity)
                    js("NB.engUpd(${q(s?.toString())})")
                    engine()
                } catch (e: Exception) { js("NB.engUpd('FAIL')") }
            }
        }

        @JavascriptInterface fun checkApp() {
            pool.execute {
                try {
                    val c = URL("https://api.github.com/repos/${BuildConfig.REPO}/releases/latest").openConnection() as HttpURLConnection
                    c.setRequestProperty("Accept", "application/vnd.github+json")
                    val j = JSONObject(c.inputStream.bufferedReader().readText())
                    val a = j.getJSONArray("assets")
                    var apk = ""
                    for (i in 0 until a.length()) if (a.getJSONObject(i).getString("name").endsWith(".apk")) apk = a.getJSONObject(i).getString("browser_download_url")
                    val tag = j.getString("tag_name")
                    val n = tag.substringAfterLast('.').toIntOrNull() ?: 0
                    val o = JSONObject().put("tag", tag).put("new", n > BuildConfig.VERSION_CODE && apk.isNotEmpty()).put("url", apk)
                    js("NB.app($o)")
                } catch (e: Exception) { js("NB.app(null)") }
            }
        }

        @JavascriptInterface fun installApp(u: String) {
            pool.execute {
                try {
                    val f = File(cacheDir, "update.apk")
                    URL(u).openStream().use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    h.post {
                        if (!packageManager.canRequestPackageInstalls()) {
                            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
                            js("NB.toast('Allow installs for BoxTube, then tap Install again')")
                        } else {
                            val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fp", f)
                            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                        }
                    }
                } catch (e: Exception) { js("NB.toast('Update failed')") }
            }
        }
    }
}
